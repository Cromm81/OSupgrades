"""
monitor.py
----------
Monitor a Windows Server upgrade batch with full SSM execution visibility.

Usage:
    python monitor.py --batch-id batch-20250912-001 [--profile PROFILE]
    python monitor.py --batch-id batch-20250912-001 --watch
    python monitor.py --batch-id batch-20250912-001 --instance-id i-xxxx
    python monitor.py --batch-id batch-20250912-001 --failures
    python monitor.py --batch-id batch-20250912-001 --instance-id i-xxxx --ssm-detail

--failures      : Show only failed instances with full error detail
--ssm-detail    : When used with --instance-id, pulls full SSM step output
--watch         : Refresh every 60s until all terminal
--watch-interval: Override refresh interval (default 60s)
"""

import argparse
import boto3
import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime, timezone

SCRIPT_DIR  = Path(__file__).parent.resolve()
CONFIG_FILE = SCRIPT_DIR / ".deploy-config.json"

TERMINAL_STATES = {
    "SUCCESS", "ROLLED_BACK", "ASSESSMENT_FAILED", "SNAPSHOT_FAILED",
    "UPGRADE_VALIDATION_FAILED", "UPGRADE_LAUNCH_FAILED",
    "ROLLBACK_FAILED", "MANUALLY_RECOVERED"
}

USE_COLOUR = os.environ.get("MONITOR_NO_COLOUR", "0") != "1"

def colour(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOUR else text

GREEN  = lambda t: colour(str(t), "32")
YELLOW = lambda t: colour(str(t), "33")
RED    = lambda t: colour(str(t), "31")
CYAN   = lambda t: colour(str(t), "36")
DIM    = lambda t: colour(str(t), "2")
BOLD   = lambda t: colour(str(t), "1")


# ── Config / auth ─────────────────────────────────────────────────────────────

def load_config():
    if not CONFIG_FILE.exists():
        print("\n  ERROR: .deploy-config.json not found. Run deploy.py first.\n")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region) if profile \
                  else boto3.Session(region_name=region)
        session.client("sts").get_caller_identity()
        return session
    except Exception as e:
        label = f"profile '{profile}'" if profile else "ambient credentials"
        print(f"\n  ERROR: Cannot authenticate with {label}: {e}\n")
        sys.exit(1)


# ── S3 helpers ────────────────────────────────────────────────────────────────

def read_manifest(s3, bucket, batch_id):
    try:
        obj = s3.get_object(Bucket=bucket, Key=f"batches/{batch_id}/manifest.json")
        return json.loads(obj["Body"].read())
    except Exception:
        return None


def list_state_files(s3, bucket, batch_id):
    keys = []
    pager = s3.get_paginator("list_objects_v2")
    for page in pager.paginate(Bucket=bucket, Prefix=f"batches/{batch_id}/state/"):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".json"):
                keys.append(obj["Key"])
    return keys


def read_state(s3, bucket, key):
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(obj["Body"].read())
    except Exception:
        return None


# ── SSM helpers ───────────────────────────────────────────────────────────────

def get_ssm_execution(ssm, exec_id):
    """Get full SSM automation execution detail."""
    try:
        resp = ssm.get_automation_execution(AutomationExecutionId=exec_id)
        return resp["AutomationExecution"]
    except Exception:
        return None


def get_failed_step_detail(ssm, execution):
    """
    Find the failed step and extract the actual error message.
    Returns (step_name, failure_message, command_output).
    """
    if not execution:
        return None, None, None

    steps = execution.get("StepExecutions", [])
    for step in steps:
        if step.get("StepStatus") in ("Failed", "TimedOut", "Cancelled"):
            step_name = step.get("StepName", "unknown")
            failure   = step.get("FailureMessage", "")

            # For aws:runCommand steps, get the actual command output
            cmd_output = None
            outputs = step.get("Outputs", {})
            if "Output" in outputs:
                cmd_output = "\n".join(outputs["Output"])
            elif "OutputPayload" in outputs:
                try:
                    payload = json.loads(outputs["OutputPayload"][0])
                    cmd_output = payload.get("Output", "")
                except Exception:
                    cmd_output = str(outputs.get("OutputPayload", ""))

            return step_name, failure, cmd_output

    return None, None, None


def find_p1_execution(ssm, batch_id, instance_id):
    """Find the P1 SSM execution for a specific instance in this batch."""
    try:
        # Search by batch tag in execution parameters
        resp = ssm.describe_automation_executions(
            Filters=[
                {"Key": "DocumentNamePrefix", "Values": ["ws-upgrade-per-instance-p1"]},
                {"Key": "ExecutionStatus",    "Values": ["InProgress", "Success", "Failed",
                                                          "TimedOut", "Cancelled", "Waiting"]}
            ],
            MaxResults=50
        )
        for ex in resp.get("AutomationExecutionMetadataList", []):
            params = ex.get("Parameters", {})
            if (params.get("InstanceId", [None])[0] == instance_id and
                    params.get("BatchId", [None])[0] == batch_id):
                return ex["AutomationExecutionId"]
    except Exception:
        pass
    return None


def find_p2_execution(ssm, batch_id, instance_id):
    """Find the P2 SSM execution for a specific instance."""
    try:
        resp = ssm.describe_automation_executions(
            Filters=[
                {"Key": "DocumentNamePrefix", "Values": ["ws-upgrade-per-instance-p2"]},
                {"Key": "ExecutionStatus",    "Values": ["InProgress", "Success", "Failed",
                                                          "TimedOut", "Cancelled", "Waiting"]}
            ],
            MaxResults=50
        )
        for ex in resp.get("AutomationExecutionMetadataList", []):
            params = ex.get("Parameters", {})
            if (params.get("InstanceId", [None])[0] == instance_id and
                    params.get("BatchId", [None])[0] == batch_id):
                return ex["AutomationExecutionId"]
    except Exception:
        pass
    return None


# ── Formatting ────────────────────────────────────────────────────────────────

def fmt_status(s):
    if not s:           return DIM("IN PROGRESS")
    if s == "SUCCESS":  return GREEN(s)
    if "FAILED" in s:   return RED(s)
    if s == "ROLLED_BACK": return YELLOW(s)
    return CYAN(s)


def fmt_phase(p):
    if not p:           return DIM("—")
    if p == "COMPLETE": return GREEN(p)
    if "FAILED" in p:   return RED(p)
    return CYAN(p)


def elapsed(ts):
    if not ts:
        return "—"
    try:
        t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        secs = int((datetime.now(timezone.utc) - t).total_seconds())
        h, r = divmod(abs(secs), 3600)
        m, s = divmod(r, 60)
        return f"{h}h{m}m{s}s" if h else f"{m}m{s}s"
    except Exception:
        return "—"


def hms(seconds):
    if not seconds:
        return "—"
    try:
        s = int(seconds)
        h, r = divmod(s, 3600)
        m, sec = divmod(r, 60)
        return f"{h}h{m}m{sec}s" if h else f"{m}m{sec}s"
    except Exception:
        return "—"


def truncate(s, n):
    s = str(s or "")
    return s[:n-3] + "..." if len(s) > n else s


# ── Summary table ─────────────────────────────────────────────────────────────

def print_manifest(manifest):
    if not manifest:
        print(DIM("  Manifest not yet written."))
        return
    s = manifest.get("summary", {})
    print(f"  Mode      : {manifest.get('target_mode','—')}")
    print(f"  Resolved  : {s.get('total_resolved','—')}  "
          f"Eligible: {GREEN(s.get('eligible','—'))}  "
          f"Ineligible: {YELLOW(s.get('ineligible', 0))}")
    for item in manifest.get("ineligible_instances", []):
        print(f"              {YELLOW(item['instance_id'])} "
              f"({item.get('server_name','')}) — {item.get('issues','')}")


def print_summary_table(states):
    if not states:
        print(DIM("  No state files found yet."))
        return {}, 0

    W = {"name": 26, "iid": 21, "phase": 26, "status": 28, "elapsed": 10}
    print(f"  {BOLD('SERVER'):<{W['name']+8}} "
          f"{BOLD('INSTANCE ID'):<{W['iid']+8}} "
          f"{BOLD('PHASE'):<{W['phase']+8}} "
          f"{BOLD('STATUS'):<{W['status']+8}} "
          f"{BOLD('ELAPSED')}")
    print("  " + "-" * 105)

    counts = {"SUCCESS": 0, "FAILED": 0, "IN_PROGRESS": 0, "OTHER": 0}
    for state in sorted(states, key=lambda x: x.get("server_name", "")):
        name   = truncate(state.get("server_name") or "—", W["name"])
        iid    = state.get("instance_id", "—")
        phase  = state.get("phase", "—")
        status = state.get("final_status")
        ts     = state.get("upgrade_started_at") or state.get("last_updated")

        if status == "SUCCESS":           counts["SUCCESS"] += 1
        elif status and "FAILED" in status: counts["FAILED"] += 1
        elif status:                       counts["OTHER"] += 1
        else:                             counts["IN_PROGRESS"] += 1

        print(f"  {name:<{W['name']}} "
              f"{iid:<{W['iid']}} "
              f"{fmt_phase(phase):<{W['phase']+16}} "
              f"{fmt_status(status):<{W['status']+16}} "
              f"{elapsed(ts)}")

    print()
    total = sum(counts.values())
    print(f"  {total} instances — "
          f"{GREEN(counts['SUCCESS'])} success  "
          f"{RED(counts['FAILED'])} failed  "
          f"{DIM(counts['IN_PROGRESS'])} in progress  "
          f"{YELLOW(counts['OTHER'])} other")
    return counts, total


# ── Failure detail ────────────────────────────────────────────────────────────

def print_failure_detail(state, ssm, batch_id):
    """Print full failure info for one instance including SSM step output."""
    iid  = state.get("instance_id", "—")
    name = state.get("server_name", iid)

    print()
    print(f"  {RED('FAILURE')} — {BOLD(name)} ({iid})")
    print(f"  {'Phase':<20}: {state.get('phase','—')}")
    print(f"  {'Status':<20}: {state.get('final_status','—')}")
    print(f"  {'Last Updated':<20}: {state.get('last_updated','—')}")

    issues = state.get("assessment_issues") or state.get("validation_issues")
    if issues:
        print(f"  {'Issues':<20}: {RED(str(issues))}")

    # Find SSM execution and get failed step detail
    exec_id = find_p1_execution(ssm, batch_id, iid)
    if not exec_id:
        exec_id = find_p2_execution(ssm, batch_id, iid)
        doc = "P2"
    else:
        doc = "P1"

    if exec_id:
        print(f"  {'SSM Execution':<20}: {exec_id} ({doc})")
        execution = get_ssm_execution(ssm, exec_id)
        if execution:
            ssm_status = execution.get("AutomationExecutionStatus", "—")
            print(f"  {'SSM Status':<20}: {ssm_status}")

            # Current/last step
            steps = execution.get("StepExecutions", [])
            running = [s for s in steps if s.get("StepStatus") == "InProgress"]
            if running:
                print(f"  {'Current Step':<20}: {CYAN(running[-1].get('StepName','—'))}")

            failed_steps = [s for s in steps if s.get("StepStatus") in ("Failed", "TimedOut")]
            for step in failed_steps:
                sname = step.get("StepName", "—")
                smsg  = step.get("FailureMessage", "")
                print(f"\n  {RED('Failed Step')}: {BOLD(sname)}")
                if smsg:
                    # Print full failure message — this is the actual error
                    for line in smsg.split("\n"):
                        line = line.strip()
                        if line:
                            print(f"    {line}")

                # Get RunCommand output if available
                outputs = step.get("Outputs", {})
                cmd_out = None
                if "Output" in outputs:
                    cmd_out = "\n".join(outputs["Output"])
                elif "OutputPayload" in outputs:
                    try:
                        p = json.loads(outputs["OutputPayload"][0])
                        cmd_out = p.get("Output", "")
                    except Exception:
                        cmd_out = str(outputs.get("OutputPayload", ""))

                if cmd_out:
                    print(f"\n  {BOLD('Step Output')}:")
                    for line in cmd_out.split("\n")[:30]:  # cap at 30 lines
                        line = line.strip()
                        if line:
                            print(f"    {line}")
    else:
        print(f"  {DIM('SSM execution not found — may have been purged or batch runner failed before P1 started')}")

    print()


# ── SSM step-by-step detail ───────────────────────────────────────────────────

def print_ssm_steps(ssm, batch_id, instance_id):
    """Print every SSM step with status and output for one instance."""
    print()
    print(BOLD(f"  SSM Step Detail — {instance_id}"))
    print()

    for doc, finder in [("P1", find_p1_execution), ("P2", find_p2_execution)]:
        exec_id = finder(ssm, batch_id, instance_id)
        if not exec_id:
            print(DIM(f"  No {doc} execution found"))
            continue

        execution = get_ssm_execution(ssm, exec_id)
        if not execution:
            print(DIM(f"  Could not retrieve {doc} execution {exec_id}"))
            continue

        print(f"  {BOLD(doc)} execution: {exec_id}  "
              f"Status: {execution.get('AutomationExecutionStatus','—')}")
        print()

        for step in execution.get("StepExecutions", []):
            sname  = step.get("StepName", "—")
            sstatus= step.get("StepStatus", "—")
            smsg   = step.get("FailureMessage", "")

            if sstatus == "Success":
                icon = GREEN("OK")
            elif sstatus in ("Failed", "TimedOut"):
                icon = RED(sstatus)
            elif sstatus == "InProgress":
                icon = CYAN("RUNNING")
            else:
                icon = DIM(sstatus)

            print(f"    {icon:<20} {sname}")

            if smsg:
                for line in smsg.split("\n")[:10]:
                    line = line.strip()
                    if line:
                        print(f"               {RED(line)}")

            # Show output for failed or runCommand steps
            outputs = step.get("Outputs", {})
            cmd_out = None
            if "Output" in outputs:
                cmd_out = "\n".join(outputs["Output"])
            elif "OutputPayload" in outputs:
                try:
                    p = json.loads(outputs["OutputPayload"][0])
                    cmd_out = p.get("Output", "")
                except Exception:
                    pass

            if cmd_out and sstatus in ("Failed", "TimedOut"):
                for line in cmd_out.split("\n")[:20]:
                    line = line.strip()
                    if line:
                        print(f"               {line}")

        print()


# ── Instance detail ───────────────────────────────────────────────────────────

def print_instance_detail(state, ssm, batch_id, ssm_detail=False):
    if not state:
        print(RED("  State file not found."))
        return

    iid = state.get("instance_id", "—")
    print()
    fields = [
        ("Instance ID",     state.get("instance_id")),
        ("Server Name",     state.get("server_name")),
        ("Phase",           state.get("phase")),
        ("Final Status",    state.get("final_status") or "IN PROGRESS"),
        ("Instance Type",   state.get("instance_type")),
        ("AZ",              state.get("az")),
        ("Root Device",     state.get("root_device")),
        ("OS Version",      state.get("os_version")),
        ("Free Space GB",   state.get("free_space_gb")),
        ("Upgrade Started", state.get("upgrade_started_at") or "—"),
        ("Elapsed",         elapsed(state.get("upgrade_started_at"))),
        ("Last Updated",    state.get("last_updated")),
    ]
    for label, value in fields:
        if value:
            print(f"  {label:<22}: {value}")

    snaps = state.get("snapshots", {})
    if snaps:
        print(f"\n  Snapshots:")
        for vol_id, snap in snaps.items():
            print(f"    {vol_id} -> {snap.get('snapshot_id','—')} "
                  f"(root={snap.get('is_root')}, status={snap.get('status')})")

    issues = state.get("assessment_issues") or state.get("validation_issues")
    if issues:
        print(f"\n  {RED('Issues')}: {issues}")

    recovery = state.get("recovery_note")
    if recovery:
        print(f"\n  {YELLOW('Recovery')}: {recovery}")

    if ssm_detail:
        print_ssm_steps(ssm, batch_id, iid)
    else:
        # Show exec IDs at minimum
        p1 = find_p1_execution(ssm, batch_id, iid)
        p2 = find_p2_execution(ssm, batch_id, iid)
        if p1 or p2:
            print(f"\n  SSM Executions:")
            if p1: print(f"    P1: {p1}")
            if p2: print(f"    P2: {p2}")
            print(f"  Tip: add --ssm-detail for full step output")


# ── Main ──────────────────────────────────────────────────────────────────────

def run_once(s3, ssm, bucket, batch_id, args):
    print()
    print("=" * 70)
    print(f"  Batch: {BOLD(batch_id)}   {DIM(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")
    print("=" * 70)

    manifest = read_manifest(s3, bucket, batch_id)
    print()
    print(BOLD("  Manifest"))
    print_manifest(manifest)

    keys   = list_state_files(s3, bucket, batch_id)
    states = [read_state(s3, bucket, k) for k in keys]
    states = [s for s in states if s]

    print()
    print(BOLD("  Instance Status"))
    print()
    counts, total = print_summary_table(states)

    # --failures: print full detail for every failed instance
    if args.failures:
        failed = [s for s in states
                  if s.get("final_status") and "FAILED" in s.get("final_status", "")]
        if not failed:
            print(f"\n  {GREEN('No failures.')} ")
        else:
            print(f"\n{BOLD('  FAILURE DETAIL')}")
            print("  " + "-" * 70)
            for s in failed:
                print_failure_detail(s, ssm, batch_id)

    # --instance-id: detail for one instance
    if args.instance_id:
        print()
        print(BOLD(f"  Detail — {args.instance_id}"))
        state = next((s for s in states if s.get("instance_id") == args.instance_id), None)
        if not state:
            state = read_state(s3, bucket,
                               f"batches/{batch_id}/state/{args.instance_id}.json")
        print_instance_detail(state, ssm, batch_id,
                              ssm_detail=getattr(args, "ssm_detail", False))

    return states


def main():
    parser = argparse.ArgumentParser(description="Monitor a Windows Server upgrade batch")
    parser.add_argument("--profile",        default=None)
    parser.add_argument("--batch-id",       required=True)
    parser.add_argument("--instance-id",    default=None)
    parser.add_argument("--watch",          action="store_true")
    parser.add_argument("--watch-interval", type=int, default=60)
    parser.add_argument("--failures",       action="store_true",
                        help="Show full error detail for all failed instances")
    parser.add_argument("--ssm-detail",     action="store_true",
                        help="Show full SSM step output (use with --instance-id)")
    parser.add_argument("--region",         default=None)

    args   = parser.parse_args()
    config = load_config()
    region = args.region or config["region"]
    session= get_session(args.profile, region)
    s3     = session.client("s3",  region_name=region)
    ssm    = session.client("ssm", region_name=region)
    bucket = config["bucket"]

    if args.watch:
        iteration = 1
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            print(DIM(f"  Refresh #{iteration} — Ctrl+C to stop"))
            states = run_once(s3, ssm, bucket, args.batch_id, args)
            terminal = all(
                s.get("final_status") in TERMINAL_STATES
                for s in states
            ) and len(states) > 0
            if terminal:
                print()
                print(GREEN("  All instances terminal."))
                break
            print()
            print(DIM(f"  Next refresh in {args.watch_interval}s — Ctrl+C to stop"))
            time.sleep(args.watch_interval)
            iteration += 1
    else:
        run_once(s3, ssm, bucket, args.batch_id, args)
        print()


if __name__ == "__main__":
    main()
