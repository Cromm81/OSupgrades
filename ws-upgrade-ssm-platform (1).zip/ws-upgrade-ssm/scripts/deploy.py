"""
deploy.py
---------
Creates the S3 bucket, IAM role, and registers both SSM Automation documents.
Run once per AWS account. Safe to re-run — checks for existing resources first.

Usage:
    python deploy.py --profile YOUR_PROFILE_NAME

Optional:
    python deploy.py --profile YOUR_PROFILE_NAME --region ca-central-1
"""

import argparse
import boto3
import json
import os
import sys
import time
from pathlib import Path

# ── Paths relative to this script ────────────────────────────────────────────
SCRIPT_DIR   = Path(__file__).parent.resolve()
PROJECT_ROOT = SCRIPT_DIR.parent
IAM_DIR      = PROJECT_ROOT / "iam"
DOCS_DIR     = PROJECT_ROOT / "documents"

TRUST_POLICY_FILE      = IAM_DIR / "trust-policy.json"
PERMISSION_POLICY_FILE = IAM_DIR / "permission-policy.json"
PER_INSTANCE_DOC       = DOCS_DIR / "ws-upgrade-per-instance.yaml"
BATCH_RUNNER_DOC       = DOCS_DIR / "ws-upgrade-batch-runner.yaml"

ROLE_NAME   = "ws-upgrade-ssm-automation-role"
POLICY_NAME = "ws-upgrade-ssm-automation-policy"


# ── Helpers ───────────────────────────────────────────────────────────────────

def banner(text):
    print(f"\n{'='*55}")
    print(f"  {text}")
    print(f"{'='*55}")

def step(n, total, text):
    print(f"\n[{n}/{total}] {text}...")

def ok(text):
    print(f"      OK  — {text}")

def skip(text):
    print(f"      SKIP — {text}")

def fail(text):
    print(f"\n  ERROR: {text}")
    sys.exit(1)


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        # Verify credentials work
        sts = session.client("sts")
        identity = sts.get_caller_identity()
        return session, identity["Account"]
    except Exception as e:
        fail(
            f"Could not authenticate with profile '{profile}'.\n"
            f"  Run:  aws configure --profile {profile}\n"
            f"  Error: {e}"
        )


def read_file(path: Path) -> str:
    if not path.exists():
        fail(f"Required file not found: {path}")
    return path.read_text(encoding="utf-8")


def inject_account(text: str, account_id: str) -> str:
    return text.replace("${ACCOUNT_ID}", account_id)


# ── S3 ────────────────────────────────────────────────────────────────────────

def create_s3_bucket(s3, region, bucket_name):
    try:
        s3.head_bucket(Bucket=bucket_name)
        skip(f"Bucket already exists: {bucket_name}")
        return
    except s3.exceptions.ClientError as e:
        if e.response["Error"]["Code"] != "404":
            # 403 means bucket exists but is owned by someone else
            if e.response["Error"]["Code"] == "403":
                fail(f"Bucket {bucket_name} exists but is not accessible — name conflict.")

    # Create bucket
    if region == "us-east-1":
        s3.create_bucket(Bucket=bucket_name)
    else:
        s3.create_bucket(
            Bucket=bucket_name,
            CreateBucketConfiguration={"LocationConstraint": region}
        )
    ok(f"Created bucket: s3://{bucket_name}")

    # Block public access
    s3.put_public_access_block(
        Bucket=bucket_name,
        PublicAccessBlockConfiguration={
            "BlockPublicAcls":       True,
            "IgnorePublicAcls":      True,
            "BlockPublicPolicy":     True,
            "RestrictPublicBuckets": True
        }
    )

    # Versioning
    s3.put_bucket_versioning(
        Bucket=bucket_name,
        VersioningConfiguration={"Status": "Enabled"}
    )

    # Default encryption
    s3.put_bucket_encryption(
        Bucket=bucket_name,
        ServerSideEncryptionConfiguration={
            "Rules": [{
                "ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}
            }]
        }
    )

    # Lifecycle — Glacier after 90 days, expire after 365
    s3.put_bucket_lifecycle_configuration(
        Bucket=bucket_name,
        LifecycleConfiguration={
            "Rules": [{
                "ID":     "archive-and-expire",
                "Status": "Enabled",
                "Filter": {"Prefix": "batches/"},
                "Transitions": [{"Days": 90, "StorageClass": "GLACIER"}],
                "Expiration": {"Days": 365}
            }]
        }
    )
    ok("Configured: versioning, encryption, lifecycle")


# ── IAM ───────────────────────────────────────────────────────────────────────

def create_iam_role(iam, account_id):
    trust_raw  = read_file(TRUST_POLICY_FILE)
    trust_json = inject_account(trust_raw, account_id)

    # Check if role exists
    try:
        iam.get_role(RoleName=ROLE_NAME)
        skip(f"Role already exists: {ROLE_NAME}")
    except iam.exceptions.NoSuchEntityException:
        iam.create_role(
            RoleName=ROLE_NAME,
            AssumeRolePolicyDocument=trust_json,
            Description="SSM Automation execution role for Windows Server upgrade platform",
            Tags=[
                {"Key": "Project",   "Value": "ws-upgrade-platform"},
                {"Key": "ManagedBy", "Value": "deploy.py"}
            ]
        )
        ok(f"Created role: {ROLE_NAME}")


def create_and_attach_policy(iam, account_id):
    perm_raw  = read_file(PERMISSION_POLICY_FILE)
    perm_json = inject_account(perm_raw, account_id)
    policy_arn = f"arn:aws:iam::{account_id}:policy/{POLICY_NAME}"

    # Check if policy exists
    try:
        iam.get_policy(PolicyArn=policy_arn)
        # Update — delete non-default versions first (AWS limit: 5 versions)
        versions = iam.list_policy_versions(PolicyArn=policy_arn)["Versions"]
        for v in versions:
            if not v["IsDefaultVersion"]:
                iam.delete_policy_version(PolicyArn=policy_arn, VersionId=v["VersionId"])
        iam.create_policy_version(
            PolicyArn=policy_arn,
            PolicyDocument=perm_json,
            SetAsDefault=True
        )
        ok(f"Updated policy: {POLICY_NAME}")
    except iam.exceptions.NoSuchEntityException:
        iam.create_policy(
            PolicyName=POLICY_NAME,
            PolicyDocument=perm_json,
            Description="Permissions for ws-upgrade SSM Automation role",
            Tags=[{"Key": "Project", "Value": "ws-upgrade-platform"}]
        )
        ok(f"Created policy: {POLICY_NAME}")

    # Attach to role
    attached = iam.list_attached_role_policies(RoleName=ROLE_NAME)["AttachedPolicies"]
    if any(p["PolicyArn"] == policy_arn for p in attached):
        skip("Policy already attached to role")
    else:
        iam.attach_role_policy(RoleName=ROLE_NAME, PolicyArn=policy_arn)
        ok("Policy attached to role")


# ── SSM Documents ─────────────────────────────────────────────────────────────

def register_ssm_document(ssm, name: str, path: Path):
    content = read_file(path)

    try:
        existing = ssm.get_document(Name=name)
        # Document exists — update it
        try:
            ssm.update_document(
                Name=name,
                Content=content,
                DocumentFormat="YAML",
                DocumentVersion="$LATEST"
            )
            ssm.update_document_default_version(Name=name, DocumentVersion="$LATEST")
            ok(f"Updated SSM document: {name}")
        except ssm.exceptions.DuplicateDocumentContent:
            skip(f"Document unchanged: {name}")
    except ssm.exceptions.InvalidDocument:
        # Does not exist — create it
        ssm.create_document(
            Name=name,
            Content=content,
            DocumentType="Automation",
            DocumentFormat="YAML",
            Tags=[{"Key": "Project", "Value": "ws-upgrade-platform"}]
        )
        ok(f"Created SSM document: {name}")


# ── Config file ───────────────────────────────────────────────────────────────

def write_config(account_id, region, bucket_name, role_arn, profile):
    config = {
        "account_id": account_id,
        "region":     region,
        "bucket":     bucket_name,
        "role_arn":   role_arn,
        "profile":    profile
    }
    config_path = SCRIPT_DIR / ".deploy-config.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    ok(f"Config written to: {config_path.name}")
    return config_path


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Deploy Windows Server Upgrade Automation Platform"
    )
    parser.add_argument(
        "--profile", required=True,
        help="AWS named profile to use (from ~/.aws/credentials)"
    )
    parser.add_argument(
        "--region", default="ca-central-1",
        help="AWS region (default: ca-central-1)"
    )
    args = parser.parse_args()

    # Auth
    session, account_id = get_session(args.profile, args.region)

    bucket_name = f"ws-upgrade-platform-{account_id}"
    role_arn    = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"

    banner("WS Upgrade Platform — Deployment")
    print(f"  Profile  : {args.profile}")
    print(f"  Account  : {account_id}")
    print(f"  Region   : {args.region}")
    print(f"  Bucket   : {bucket_name}")
    print(f"  Role     : {ROLE_NAME}")

    s3  = session.client("s3",  region_name=args.region)
    iam = session.client("iam")   # IAM is global — no region needed
    ssm = session.client("ssm", region_name=args.region)

    # Step 1 — S3
    step(1, 5, "Creating S3 bucket")
    create_s3_bucket(s3, args.region, bucket_name)

    # Step 2 — IAM Role
    step(2, 5, "Creating IAM role")
    create_iam_role(iam, account_id)

    # Step 3 — IAM Policy
    step(3, 5, "Creating and attaching IAM policy")
    create_and_attach_policy(iam, account_id)

    # Wait for IAM propagation before registering SSM docs
    print("      Waiting 10s for IAM propagation...")
    time.sleep(10)

    # Step 4 — Per-instance document
    step(4, 5, "Registering SSM document: ws-upgrade-per-instance")
    register_ssm_document(ssm, "ws-upgrade-per-instance", PER_INSTANCE_DOC)

    # Step 5 — Batch runner document
    step(5, 5, "Registering SSM document: ws-upgrade-batch-runner")
    register_ssm_document(ssm, "ws-upgrade-batch-runner", BATCH_RUNNER_DOC)

    # Write config for other scripts
    config_path = write_config(account_id, args.region, bucket_name, role_arn, args.profile)

    banner("Deployment Complete")
    print(f"  S3 Bucket   : s3://{bucket_name}")
    print(f"  Role ARN    : {role_arn}")
    print(f"  Documents   : ws-upgrade-per-instance")
    print(f"                ws-upgrade-batch-runner")
    print()
    print("  Next steps:")
    print("    1. Stage upgrade media on target instances")
    print("    2. Tag instances with your wave tag")
    print(f"   3. python run_batch.py --profile {args.profile} --help")
    print()


if __name__ == "__main__":
    main()
