"""
run_batch.py
------------
Starts a Windows Server upgrade batch via SSM Automation.

Two targeting modes:
  --tag-key / --tag-value   Target all running Windows instances with matching EC2 tag
  --instance-ids            Target specific instances (comma-separated)

Usage examples:

  Tag-based (recommended for waves):
    python run_batch.py --profile YOUR_PROFILE --batch-id batch-20250912-001 ^
        --tag-key WS-Upgrade-Wave --tag-value Wave-01

  Instance list:
    python run_batch.py --profile YOUR_PROFILE --batch-id batch-20250912-001 ^
        --instance-ids i-0abc1234,i-0def5678

Optional overrides:
  --max-concurrency         (default: 5)
  --min-free-space-gb       (default: 20)
  --upgrade-timeout-mins    (default: 120)
  --post-reboot-wait-secs   (default: 1200)
  --snapshot-timeout-secs   (default: 3600)
  --region                  (default: from deploy config or ca-central-1)
"""

import argparse
import boto3
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR   = Path(__file__).parent.resolve()
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_FILE  = SCRIPT_DIR / ".deploy-config.json"
HISTORY_DIR  = PROJECT_ROOT / "batch-history"

BATCH_ID_PATTERN = re.compile(r"^batch-[a-zA-Z0-9\-]+$")


# ── Config ────────────────────────────────────────────────────────────────────

def load_config():
    if not CONFIG_FILE.exists():
        print("\n  ERROR: .deploy-config.json not found.")
        print("  Run deploy.py first:\n")
        print("    python deploy.py --profile YOUR_PROFILE\n")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        sts     = session.client("sts")
        sts.get_caller_identity()
        return session
    except Exception as e:
        print(f"\n  ERROR: Cannot authenticate with profile '{profile}': {e}\n")
        sys.exit(1)


# ── Validation ────────────────────────────────────────────────────────────────

def validate_args(args):
    errors = []

    if not BATCH_ID_PATTERN.match(args.batch_id):
        errors.append(
            f"Batch ID '{args.batch_id}' is invalid.\n"
            f"    Must match: batch-{{letters-numbers-hyphens}}\n"
            f"    Example:    batch-20250912-001"
        )

    tag_mode  = bool(args.tag_key or args.tag_value)
    list_mode = bool(args.instance_ids)

    if tag_mode and list_mode:
        errors.append("Use either --tag-key/--tag-value OR --instance-ids, not both.")

    if not tag_mode and not list_mode:
        errors.append("Specify either --tag-key + --tag-value, or --instance-ids.")

    if args.tag_key and not args.tag_value:
        errors.append("--tag-value is required when --tag-key is provided.")

    if args.tag_value and not args.tag_key:
        errors.append("--tag-key is required when --tag-value is provided.")

    if args.instance_ids:
        id_pattern = re.compile(r"^i-[0-9a-f]{8,17}$")
        ids = [i.strip() for i in args.instance_ids.split(",") if i.strip()]
        bad = [i for i in ids if not id_pattern.match(i)]
        if bad:
            errors.append(f"Invalid instance ID format: {bad}")
        if not ids:
            errors.append("--instance-ids cannot be empty.")

    if errors:
        print("\n  Argument errors:")
        for e in errors:
            print(f"    - {e}")
        print()
        sys.exit(1)

    return "ByTag" if tag_mode else "ByInstanceList"


# ── Confirmation prompt ───────────────────────────────────────────────────────

def confirm(args, config, target_mode):
    print()
    print("=" * 55)
    print("  WS Upgrade — Batch Configuration")
    print("=" * 55)
    print(f"  Profile          : {args.profile}")
    print(f"  Account          : {config['account_id']}")
    print(f"  Region           : {config['region']}")
    print(f"  Batch ID         : {args.batch_id}")
    print(f"  Target Mode      : {target_mode}")
    if target_mode == "ByTag":
        print(f"  Tag              : {args.tag_key} = {args.tag_value}")
    else:
        ids = [i.strip() for i in args.instance_ids.split(",") if i.strip()]
        print(f"  Instances        : {len(ids)} specified")
        for iid in ids:
            print(f"                     {iid}")
    print(f"  Max Concurrency  : {args.max_concurrency}")
    print(f"  Min Free Space   : {args.min_free_space_gb} GB")
    print(f"  Upgrade Timeout  : {args.upgrade_timeout_mins} min")
    print(f"  Post-Reboot Wait : {args.post_reboot_wait_secs} sec")
    print(f"  Snapshot Timeout : {args.snapshot_timeout_secs} sec")
    print(f"  S3 Bucket        : s3://{config['bucket']}")
    print("=" * 55)
    print()
    print("  WARNING: This will initiate in-place OS upgrades.")
    print("  Servers will reboot. Automated rollback is available")
    print("  but manual recovery may be required if rollback fails.")
    print()

    answer = input("  Type YES to proceed: ").strip()
    if answer != "YES":
        print("\n  Aborted. Nothing was started.\n")
        sys.exit(0)


# ── Start batch ───────────────────────────────────────────────────────────────

def start_batch(ssm, args, config, target_mode):
    params = {
        "BatchId":               [args.batch_id],
        "S3Bucket":              [config["bucket"]],
        "AutomationAssumeRole":  [config["role_arn"]],
        "TargetMode":            [target_mode],
        "TagKey":                [args.tag_key or ""],
        "TagValue":              [args.tag_value or ""],
        "InstanceIds":           [args.instance_ids or ""],
        "MaxConcurrency":        [str(args.max_concurrency)],
        "MinFreeSpaceGB":        [str(args.min_free_space_gb)],
        "UpgradeTimeoutMinutes": [str(args.upgrade_timeout_mins)],
        "PostRebootWaitSeconds": [str(args.post_reboot_wait_secs)],
        "SnapshotTimeoutSeconds":[str(args.snapshot_timeout_secs)],
    }

    try:
        response = ssm.start_automation_execution(
            DocumentName="ws-upgrade-batch-runner",
            Parameters=params
        )
        return response["AutomationExecutionId"]
    except ssm.exceptions.InvalidDocument:
        print("\n  ERROR: SSM document 'ws-upgrade-batch-runner' not found.")
        print("  Run deploy.py first.\n")
        sys.exit(1)
    except Exception as e:
        print(f"\n  ERROR starting automation: {e}\n")
        sys.exit(1)


def save_history(args, config, execution_id, target_mode):
    HISTORY_DIR.mkdir(exist_ok=True)
    record = {
        "batch_id":     args.batch_id,
        "execution_id": execution_id,
        "target_mode":  target_mode,
        "tag_key":      args.tag_key or "",
        "tag_value":    args.tag_value or "",
        "instance_ids": args.instance_ids or "",
        "started_at":   datetime.now(timezone.utc).isoformat(),
        "account_id":   config["account_id"],
        "region":       config["region"],
        "bucket":       config["bucket"]
    }
    path = HISTORY_DIR / f"{args.batch_id}.json"
    path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    return path


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Start a Windows Server upgrade batch",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument("--profile",    required=True, help="AWS named profile")
    parser.add_argument("--batch-id",   required=True, help="Unique batch ID (e.g. batch-20250912-001)")
    parser.add_argument("--tag-key",    default="",    help="EC2 tag key for target selection")
    parser.add_argument("--tag-value",  default="",    help="EC2 tag value for target selection")
    parser.add_argument("--instance-ids", default="", help="Comma-separated instance IDs")
    parser.add_argument("--max-concurrency",        type=int, default=5,    help="Max parallel upgrades (default: 5)")
    parser.add_argument("--min-free-space-gb",      type=int, default=20,   help="Min C: free space GB (default: 20)")
    parser.add_argument("--upgrade-timeout-mins",   type=int, default=120,  help="Upgrade timeout minutes (default: 120)")
    parser.add_argument("--post-reboot-wait-secs",  type=int, default=1200, help="Post-reboot wait seconds (default: 1200)")
    parser.add_argument("--snapshot-timeout-secs",  type=int, default=3600, help="Snapshot timeout seconds (default: 3600)")
    parser.add_argument("--region", default=None, help="Override region from deploy config")

    args = parser.parse_args()

    config      = load_config()
    region      = args.region or config["region"]
    target_mode = validate_args(args)
    session     = get_session(args.profile, region)
    ssm         = session.client("ssm", region_name=region)

    confirm(args, config, target_mode)

    print("\n  Starting batch automation...")
    execution_id = start_batch(ssm, args, config, target_mode)
    history_path = save_history(args, config, execution_id, target_mode)

    region_url = region.replace("-", "-")
    console_url = (
        f"https://{region}.console.aws.amazon.com/systems-manager"
        f"/automation/executions/{execution_id}?region={region}"
    )

    print()
    print("=" * 55)
    print("  Batch started successfully.")
    print("=" * 55)
    print(f"  Execution ID  : {execution_id}")
    print(f"  Batch ID      : {args.batch_id}")
    print()
    print("  Monitor:")
    print(f"    python monitor.py --profile {args.profile} --batch-id {args.batch_id}")
    print()
    print("  SSM Console:")
    print(f"    {console_url}")
    print()
    print(f"  Local record: {history_path.relative_to(PROJECT_ROOT)}")
    print()


if __name__ == "__main__":
    main()
