"""
monitor.py
----------
Shows status of a running or completed upgrade batch.

Usage:
    python monitor.py --profile YOUR_PROFILE --batch-id batch-20250912-001

Options:
    --instance-id   Show full state detail for a specific instance
    --watch         Refresh every 60 seconds until all instances reach a terminal state
    --region        Override region from deploy config
"""

import argparse
import boto3
import json
import sys
import time
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
CONFIG_FILE = SCRIPT_DIR / ".deploy-config.json"

TERMINAL_STATES = {"SUCCESS", "ROLLED_BACK", "ASSESSMENT_FAILED", "SNAPSHOT_FAILED",
                   "ROLLBACK_FAILED", "MANUALLY_RECOVERED"}

# Colour codes — Windows cmd supports these via ANSI if you're on Win10+
# If colours look wrong, set MONITOR_NO_COLOUR=1 in your environment
import os
USE_COLOUR = os.environ.get("MONITOR_NO_COLOUR", "0") != "1"

def colour(text, code):
    if not USE_COLOUR:
        return text
    return f"\033[{code}m{text}\033[0m"

GREEN  = lambda t: colour(t, "32")
YELLOW = lambda t: colour(t, "33")
RED    = lambda t: colour(t, "31")
CYAN   = lambda t: colour(t, "36")
DIM    = lambda t: colour(t, "2")
BOLD   = lambda t: colour(t, "1")


# ── Config ────────────────────────────────────────────────────────────────────

def load_config():
    if not CONFIG_FILE.exists():
        print("\n  ERROR: .deploy-config.json not found. Run deploy.py first.\n")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        session.client("sts").get_caller_identity()
        return session
    except Exception as e:
        print(f"\n  ERROR: Cannot authenticate with profile '{profile}': {e}\n")
        sys.exit(1)


# ── S3 reads ──────────────────────────────────────────────────────────────────

def read_manifest(s3, bucket, batch_id):
    try:
        obj = s3.get_object(Bucket=bucket, Key=f"batches/{batch_id}/manifest.json")
        return json.loads(obj["Body"].read())
    except Exception:
        return None


def list_state_files(s3, bucket, batch_id):
    keys = []
    paginator = s3.get_paginator("list_objects_v2")
    prefix    = f"batches/{batch_id}/state/"
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".json"):
                keys.append(obj["Key"])
    return keys


def read_state(s3, bucket, key):
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(obj["Body"].read())
    except Exception:
        return None


# ── Formatting ────────────────────────────────────────────────────────────────

def format_status(final_status):
    if not final_status:
        return DIM("—")
    if final_status == "SUCCESS":
        return GREEN(final_status)
    if final_status == "ROLLED_BACK":
        return YELLOW(final_status)
    if "FAILED" in final_status:
        return RED(final_status)
    return final_status


def format_phase(phase):
    if not phase:
        return DIM("—")
    if phase in ("COMPLETE",):
        return GREEN(phase)
    if "FAILED" in phase:
        return RED(phase)
    if phase in ("ROLLBACK", "ROLLBACK_FAILED"):
        return RED(phase)
    return CYAN(phase)


def seconds_to_hms(seconds):
    if not seconds:
        return "—"
    try:
        s   = int(seconds)
        h, rem = divmod(s, 3600)
        m, sec = divmod(rem, 60)
        return f"{h}h {m}m {sec}s" if h else f"{m}m {sec}s"
    except Exception:
        return "—"


# ── Display ───────────────────────────────────────────────────────────────────

def print_manifest(manifest):
    if not manifest:
        print(DIM("  Manifest not yet written — batch runner may still be starting."))
        return
    s = manifest.get("summary", {})
    print(f"  Mode      : {manifest.get('target_mode','—')}", end="")
    if manifest.get("tag_key"):
        print(f"  ({manifest['tag_key']} = {manifest.get('tag_value','')})", end="")
    print()
    print(f"  Resolved  : {s.get('total_resolved','—')}")
    print(f"  Eligible  : {GREEN(str(s.get('eligible','—')))}")
    inelig = s.get("ineligible", 0)
    if inelig:
        print(f"  Ineligible: {YELLOW(str(inelig))}")
        for item in manifest.get("ineligible_instances", []):
            print(f"              {item['instance_id']} ({item.get('server_name','')}) — {item.get('issues',[])}")


def print_status_table(states):
    if not states:
        print(DIM("  No state files found yet."))
        return

    col_name   = 24
    col_iid    = 22
    col_phase  = 28
    col_status = 22
    col_dur    = 12

    hdr = (
        f"  {BOLD('SERVER NAME'):<{col_name+8}} "
        f"{BOLD('INSTANCE ID'):<{col_iid+8}} "
        f"{BOLD('PHASE'):<{col_phase+8}} "
        f"{BOLD('FINAL STATUS'):<{col_status+8}} "
        f"{BOLD('DURATION')}"
    )
    print(hdr)
    print("  " + "-" * (col_name + col_iid + col_phase + col_status + col_dur + 12))

    counts = {"SUCCESS": 0, "ROLLED_BACK": 0, "FAILED": 0, "IN_PROGRESS": 0}

    for state in sorted(states, key=lambda x: x.get("server_name", "")):
        name         = (state.get("server_name") or "—")[:col_name]
        iid          = state.get("instance_id", "—")
        phase        = state.get("phase", "—")
        final_status = state.get("final_status")
        duration     = seconds_to_hms(state.get("upgrade_duration_seconds"))

        # Count for summary
        if final_status == "SUCCESS":
            counts["SUCCESS"] += 1
        elif final_status == "ROLLED_BACK":
            counts["ROLLED_BACK"] += 1
        elif final_status and "FAILED" in final_status:
            counts["FAILED"] += 1
        else:
            counts["IN_PROGRESS"] += 1

        print(
            f"  {name:<{col_name}} "
            f"{iid:<{col_iid}} "
            f"{format_phase(phase):<{col_phase + 16}} "
            f"{format_status(final_status):<{col_status + 16}} "
            f"{duration}"
        )

    print()
    print(
        f"  Summary — "
        f"{GREEN(str(counts['SUCCESS']))} succeeded  "
        f"{YELLOW(str(counts['ROLLED_BACK']))} rolled back  "
        f"{RED(str(counts['FAILED']))} failed  "
        f"{DIM(str(counts['IN_PROGRESS']))} in progress"
    )
    return counts


def print_instance_detail(state):
    if not state:
        print(RED("  State file not found for this instance."))
        return

    print()
    fields = [
        ("Instance ID",       state.get("instance_id")),
        ("Server Name",       state.get("server_name")),
        ("Phase",             state.get("phase")),
        ("Final Status",      state.get("final_status") or "—"),
        ("Instance Type",     state.get("instance_type")),
        ("AZ",                state.get("az")),
        ("Root Device",       state.get("root_device")),
        ("Upgrade Started",   state.get("upgrade_started_at") or "—"),
        ("Upgrade Completed", state.get("upgrade_completed_at") or "—"),
        ("Duration",          seconds_to_hms(state.get("upgrade_duration_seconds"))),
        ("Validation Passed", state.get("validation_passed")),
        ("Rollback Triggered",state.get("rollback_triggered")),
        ("Rollback Reason",   state.get("rollback_reason") or "—"),
        ("Last Updated",      state.get("last_updated")),
    ]
    for label, value in fields:
        print(f"  {label:<22}: {value}")

    snaps = state.get("snapshots", {})
    if snaps:
        print(f"\n  {'Snapshots':}")
        for vol_id, snap in snaps.items():
            print(f"    Vol {vol_id} → {snap.get('snapshot_id','—')}  "
                  f"(root={snap.get('is_root')}, status={snap.get('status')})")

    issues = state.get("assessment_issues") or state.get("validation_issues")
    if issues:
        print(f"\n  Issues: {RED(str(issues))}")


def all_terminal(states):
    return all(
        s.get("final_status") in TERMINAL_STATES
        for s in states if s.get("final_status")
    ) and len(states) > 0


# ── Main ──────────────────────────────────────────────────────────────────────

def run_once(s3, bucket, batch_id, instance_id=None):
    print()
    print("=" * 55)
    print(f"  Batch: {BOLD(batch_id)}")
    print("=" * 55)

    manifest = read_manifest(s3, bucket, batch_id)
    print()
    print(BOLD("  Manifest"))
    print_manifest(manifest)

    state_keys = list_state_files(s3, bucket, batch_id)
    states = []
    for key in state_keys:
        state = read_state(s3, bucket, key)
        if state:
            states.append(state)

    print()
    print(BOLD("  Instance Status"))
    print()
    counts = print_status_table(states)

    if instance_id:
        print()
        print(BOLD(f"  Detail: {instance_id}"))
        state = next((s for s in states if s.get("instance_id") == instance_id), None)
        if not state:
            # Try loading directly
            key   = f"batches/{batch_id}/state/{instance_id}.json"
            state = read_state(s3, bucket, key)
        print_instance_detail(state)

    return states


def main():
    parser = argparse.ArgumentParser(
        description="Monitor a Windows Server upgrade batch",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument("--profile",     required=True, help="AWS named profile")
    parser.add_argument("--batch-id",    required=True, help="Batch ID to monitor")
    parser.add_argument("--instance-id", default=None,  help="Show full detail for one instance")
    parser.add_argument("--watch",       action="store_true",
                        help="Refresh every 60s until all instances complete")
    parser.add_argument("--watch-interval", type=int, default=60,
                        help="Refresh interval in seconds when using --watch (default: 60)")
    parser.add_argument("--region", default=None, help="Override region from deploy config")

    args    = parser.parse_args()
    config  = load_config()
    region  = args.region or config["region"]
    session = get_session(args.profile, region)
    s3      = session.client("s3", region_name=region)
    bucket  = config["bucket"]

    if args.watch:
        iteration = 1
        while True:
            # Clear screen on Windows
            os.system("cls")
            print(DIM(f"  Refresh #{iteration} — Ctrl+C to stop"))
            states = run_once(s3, bucket, args.batch_id, args.instance_id)
            if all_terminal(states):
                print()
                print(GREEN("  All instances have reached a terminal state."))
                print()
                break
            print()
            print(DIM(f"  Next refresh in {args.watch_interval}s — Ctrl+C to stop"))
            time.sleep(args.watch_interval)
            iteration += 1
    else:
        run_once(s3, bucket, args.batch_id, args.instance_id)
        print()


if __name__ == "__main__":
    main()
