"""
run_batch.py
------------
Run a setup or cleanup batch against a set of instances.

Setup mode (attach media, ready for upgrade):
    python run_batch.py --mode Setup
        --batch-id batch-evergreen2026-001
        --instance-ids i-aaa,i-bbb
        --media-snapshot-id snap-xxxx
        [--profile PROFILE]

    OR by tag:
        --tag-key Upgrade --tag-value Evergreen2026

Cleanup mode (validate OS, detach and delete media volume):
    python run_batch.py --mode Cleanup
        --batch-id batch-evergreen2026-001
        --instance-ids i-aaa,i-bbb
        [--profile PROFILE]
"""
import argparse
import boto3
import json
import sys
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
CONFIG_FILE = SCRIPT_DIR / ".deploy-config.json"


def load_config():
    if not CONFIG_FILE.exists():
        print("\n  ERROR: .deploy-config.json not found. Run deploy.py first.\n")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region) if profile \
                  else boto3.Session(region_name=region)
        ident = session.client("sts").get_caller_identity()
        return session, ident["Account"]
    except Exception as e:
        print(f"\n  ERROR: Auth failed: {e}\n")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Run a ws-upgrade batch")
    parser.add_argument("--profile",           default=None)
    parser.add_argument("--batch-id",          required=True)
    parser.add_argument("--mode",              required=True, choices=["Setup", "Cleanup"])
    parser.add_argument("--instance-ids",      default=None, help="Comma-separated instance IDs")
    parser.add_argument("--tag-key",           default=None)
    parser.add_argument("--tag-value",         default=None)
    parser.add_argument("--media-snapshot-id", default=None, help="Required for Setup mode")
    parser.add_argument("--max-concurrency",   type=int, default=5)
    parser.add_argument("--min-free-space-gb", type=int, default=20)
    parser.add_argument("--snapshot-timeout",  type=int, default=3600)
    parser.add_argument("--region",            default=None)
    args = parser.parse_args()

    config  = load_config()
    region  = args.region or config["region"]
    session, account_id = get_session(args.profile, region)

    # Validate
    if args.mode == "Setup" and not args.media_snapshot_id:
        print("\n  ERROR: --media-snapshot-id required for Setup mode\n")
        sys.exit(1)

    if not args.instance_ids and not (args.tag_key and args.tag_value):
        print("\n  ERROR: Provide --instance-ids or both --tag-key and --tag-value\n")
        sys.exit(1)

    target_mode = "ByTag" if (args.tag_key and args.tag_value) else "ByInstanceList"

    print()
    print("=" * 60)
    print(f"  WS Upgrade Platform - {args.mode} Batch")
    print("=" * 60)
    print(f"  Account     : {account_id}")
    print(f"  Region      : {region}")
    print(f"  Batch ID    : {args.batch_id}")
    print(f"  Mode        : {args.mode}")
    print(f"  Target      : {target_mode}")
    if target_mode == "ByInstanceList":
        print(f"  Instances   : {args.instance_ids}")
    else:
        print(f"  Tag         : {args.tag_key}={args.tag_value}")
    if args.mode == "Setup":
        print(f"  Snapshot    : {args.media_snapshot_id}")
    print(f"  Concurrency : {args.max_concurrency}")
    print()

    confirm = input("  Type YES to proceed: ").strip().upper()
    if confirm != "YES":
        print("\n  Aborted.\n")
        sys.exit(0)

    ssm = session.client("ssm", region_name=region)

    params = {
        "BatchId":              [args.batch_id],
        "S3Bucket":             [config["bucket"]],
        "AutomationAssumeRole": [config["role_arn"]],
        "Mode":                 [args.mode],
        "TargetMode":           [target_mode],
        "TagKey":               [args.tag_key   or "unused"],
        "TagValue":             [args.tag_value  or "unused"],
        "InstanceIds":          [args.instance_ids or "unused"],
        "MediaSnapshotId":      [args.media_snapshot_id or "unused"],
        "MaxConcurrency":       [str(args.max_concurrency)],
        "MinFreeSpaceGB":       [str(args.min_free_space_gb)],
        "SnapshotTimeoutSeconds":[str(args.snapshot_timeout)],
        "ProjectTag":           [config.get("project_tag", "ws-upgrade")],
    }

    try:
        resp = ssm.start_automation_execution(
            DocumentName="ws-upgrade-batch-runner",
            Parameters=params
        )
        exec_id = resp["AutomationExecutionId"]
        print(f"\n  Batch started: {exec_id}")
        print(f"\n  Monitor:")
        print(f"    python monitor.py --batch-id {args.batch_id}" +
              (f" --profile {args.profile}" if args.profile else ""))
        print()
    except Exception as e:
        print(f"\n  ERROR: Failed to start batch: {e}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
