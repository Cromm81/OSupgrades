"""
deploy.py
---------
Creates S3 bucket, IAM role/policy, registers SSM documents.
Run once before first use, and after any document changes.

Usage:
    python deploy.py [--profile PROFILE] [--region REGION]
"""
import argparse
import boto3
import json
import sys
import time
from pathlib import Path

SCRIPT_DIR   = Path(__file__).parent.resolve()
DOCS_DIR     = SCRIPT_DIR.parent / "documents"
IAM_DIR      = SCRIPT_DIR.parent / "iam"
CONFIG_FILE  = SCRIPT_DIR / ".deploy-config.json"

DOCUMENTS = [
    "ws-upgrade-batch-runner",
    "ws-upgrade-setup",
    "ws-upgrade-cleanup",
]

def ok(msg):   print(f"  [OK]   {msg}")
def skip(msg): print(f"  [SKIP] {msg}")
def info(msg): print(f"  [INFO] {msg}")
def err(msg):  print(f"  [ERR]  {msg}")


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region) if profile \
                  else boto3.Session(region_name=region)
        ident = session.client("sts").get_caller_identity()
        return session, ident["Account"]
    except Exception as e:
        err(f"Auth failed: {e}")
        sys.exit(1)


def ensure_s3_bucket(s3, account_id, region):
    bucket = f"ws-upgrade-platform-{account_id}"
    try:
        s3.head_bucket(Bucket=bucket)
        skip(f"S3 bucket exists: {bucket}")
    except Exception:
        if region == "us-east-1":
            s3.create_bucket(Bucket=bucket)
        else:
            s3.create_bucket(
                Bucket=bucket,
                CreateBucketConfiguration={"LocationConstraint": region}
            )
        s3.put_bucket_versioning(
            Bucket=bucket,
            VersioningConfiguration={"Status": "Enabled"}
        )
        ok(f"Created S3 bucket: {bucket}")
    return bucket


def ensure_iam_role(iam, account_id):
    role_name   = "ws-upgrade-ssm-automation-role"
    policy_name = "ws-upgrade-ssm-automation-policy"

    trust = json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "ssm.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    })

    # Role
    try:
        role = iam.get_role(RoleName=role_name)
        skip(f"IAM role exists: {role_name}")
        role_arn = role["Role"]["Arn"]
    except iam.exceptions.NoSuchEntityException:
        role = iam.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=trust,
            Description="SSM Automation role for Windows Server upgrade platform"
        )
        role_arn = role["Role"]["Arn"]
        ok(f"Created IAM role: {role_name}")

    # Policy document
    policy_doc = json.dumps({
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "SSMAutomation",
                "Effect": "Allow",
                "Action": [
                    "ssm:StartAutomationExecution",
                    "ssm:GetAutomationExecution",
                    "ssm:ListAutomationExecutions",
                    "ssm:DescribeAutomationExecutions",
                    "ssm:SendCommand",
                    "ssm:GetCommandInvocation",
                    "ssm:ListCommandInvocations",
                    "ssm:ListCommands",
                    "ssm:DescribeInstanceInformation"
                ],
                "Resource": "*"
            },
            {
                "Sid": "EC2",
                "Effect": "Allow",
                "Action": [
                    "ec2:DescribeInstances",
                    "ec2:DescribeInstanceStatus",
                    "ec2:DescribeVolumes",
                    "ec2:DescribeSnapshots",
                    "ec2:DescribeTags",
                    "ec2:CreateSnapshot",
                    "ec2:DeleteSnapshot",
                    "ec2:CreateVolume",
                    "ec2:DeleteVolume",
                    "ec2:AttachVolume",
                    "ec2:DetachVolume",
                    "ec2:CreateTags",
                    "ec2:ModifyInstanceAttribute"
                ],
                "Resource": "*"
            },
            {
                "Sid": "S3",
                "Effect": "Allow",
                "Action": [
                    "s3:GetObject",
                    "s3:PutObject",
                    "s3:DeleteObject",
                    "s3:ListBucket"
                ],
                "Resource": [
                    f"arn:aws:s3:::ws-upgrade-platform-{account_id}",
                    f"arn:aws:s3:::ws-upgrade-platform-{account_id}/*"
                ]
            },
            {
                "Sid": "KMS",
                "Effect": "Allow",
                "Action": [
                    "kms:Decrypt",
                    "kms:GenerateDataKey",
                    "kms:CreateGrant",
                    "kms:DescribeKey",
                    "kms:ReEncrypt*"
                ],
                "Resource": "*"
            }
        ]
    })

    # Inline policy
    try:
        iam.put_role_policy(
            RoleName=role_name,
            PolicyName=policy_name,
            PolicyDocument=policy_doc
        )
        ok(f"Updated IAM inline policy: {policy_name}")
    except Exception as e:
        err(f"Failed to update IAM policy: {e}")
        sys.exit(1)

    return role_arn


def register_ssm_document(ssm, name, path, project_tag):
    content = path.read_text(encoding="utf-8")
    try:
        ssm.get_document(Name=name)
        # Exists - try to update
        try:
            resp = ssm.update_document(
                Name=name,
                Content=content,
                DocumentFormat="YAML",
                DocumentVersion="$LATEST"
            )
            new_ver = resp["DocumentDescription"]["DocumentVersion"]
            ssm.update_document_default_version(Name=name, DocumentVersion=new_ver)
            ok(f"Updated SSM document: {name} (v{new_ver})")
        except ssm.exceptions.DuplicateDocumentContent:
            skip(f"Document unchanged: {name}")
        except Exception as e:
            # Update failed - delete and recreate
            info(f"Update failed ({e}) - deleting and recreating {name}...")
            ssm.delete_document(Name=name)
            time.sleep(3)
            ssm.create_document(
                Name=name,
                Content=content,
                DocumentType="Automation",
                DocumentFormat="YAML",
                Tags=[
                    {"Key": "Project",   "Value": "ws-upgrade-platform"},
                    {"Key": "Evergreen", "Value": project_tag}
                ]
            )
            ok(f"Recreated SSM document: {name}")
    except ssm.exceptions.InvalidDocument:
        ssm.create_document(
            Name=name,
            Content=content,
            DocumentType="Automation",
            DocumentFormat="YAML",
            Tags=[
                {"Key": "Project",   "Value": "ws-upgrade-platform"},
                {"Key": "Evergreen", "Value": project_tag}
            ]
        )
        ok(f"Created SSM document: {name}")


def main():
    parser = argparse.ArgumentParser(description="Deploy ws-upgrade platform")
    parser.add_argument("--profile", default=None)
    parser.add_argument("--region",  default="ca-central-1")
    args = parser.parse_args()

    print()
    print("=" * 60)
    print("  WS Upgrade Platform - Deploy")
    print("=" * 60)

    session, account_id = get_session(args.profile, args.region)
    print(f"\n  Account : {account_id}")
    print(f"  Region  : {args.region}")
    print()

    project_tag = input("  Project tag (e.g. Evergreen2026): ").strip()
    if not project_tag:
        err("Project tag required")
        sys.exit(1)

    confirm = input(f"\n  Deploy to account {account_id}? Type YES to confirm: ").strip().upper()
    if confirm != "YES":
        print("\n  Aborted.\n")
        sys.exit(0)

    print()
    s3  = session.client("s3",  region_name=args.region)
    iam = session.client("iam")
    ssm = session.client("ssm", region_name=args.region)

    # S3
    print("  S3 Bucket")
    bucket = ensure_s3_bucket(s3, account_id, args.region)

    # IAM
    print("  IAM Role")
    role_arn = ensure_iam_role(iam, account_id)
    print(f"  Role ARN: {role_arn}")

    # SSM documents
    print("  SSM Documents")
    for doc_name in DOCUMENTS:
        doc_path = DOCS_DIR / f"{doc_name}.yaml"
        if not doc_path.exists():
            err(f"Document not found: {doc_path}")
            sys.exit(1)
        register_ssm_document(ssm, doc_name, doc_path, project_tag)

    # Write config
    config = {
        "account_id":  account_id,
        "region":      args.region,
        "bucket":      bucket,
        "role_arn":    role_arn,
        "project_tag": project_tag
    }
    CONFIG_FILE.write_text(json.dumps(config, indent=2), encoding="utf-8")
    ok(f"Wrote config: {CONFIG_FILE}")

    print()
    print("  Deploy complete.")
    print()
    print("  Next steps:")
    print("    1. Run setup batch:   python run_batch.py --mode Setup --batch-id ... --media-snapshot-id snap-...")
    print("    2. Execute upgrade:   On each machine: Set-Location Z:\\ ; .\\setup.exe /auto upgrade /dynamicupdate disable")
    print("    3. After all done:    python run_batch.py --mode Cleanup --batch-id ...")
    print()


if __name__ == "__main__":
    main()
