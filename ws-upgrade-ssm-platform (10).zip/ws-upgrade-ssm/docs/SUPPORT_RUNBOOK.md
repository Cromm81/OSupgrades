# Support Runbook
## Windows Server Upgrade Automation Platform — SSM Native

---

## Where to Look First

Every failure has two places to triage:

**1. SSM Automation Console**
AWS Console → Systems Manager → Automation → Executions
- Find the execution for the instance (filter by document `ws-upgrade-per-instance`)
- Click through to see exactly which step failed, the full PowerShell output, and the error message

**2. S3 State File**
```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
aws s3 cp s3://ws-upgrade-platform-${ACCOUNT_ID}/batches/{BATCH_ID}/state/{INSTANCE_ID}.json - \
  | python3 -m json.tool
```

Key fields in the state file:

| Field | Meaning |
|---|---|
| `phase` | Last phase reached |
| `final_status` | Terminal status (SUCCESS, ROLLED_BACK, *_FAILED) |
| `assessment_issues` | Which assessment checks failed |
| `validation_issues` | Which post-upgrade checks failed |
| `rollback_triggered` | true if rollback was initiated |
| `rollback_reason` | Why rollback was triggered |
| `snapshots` | All snapshot IDs created — needed for manual recovery |

---

## Final Status Reference

| Status | Meaning | Server State |
|---|---|---|
| `SUCCESS` | Upgraded and validated | Running WS2025 |
| `ROLLED_BACK` | Upgrade failed, server restored | Running WS2019 (original state) |
| `ASSESSMENT_FAILED` | Pre-checks failed, never touched | Running WS2019, unchanged |
| `SNAPSHOT_FAILED` | Snapshot did not complete | Running WS2019, no snapshot |
| `ROLLBACK_FAILED` | **Critical** — upgrade AND rollback failed | Unknown — manual recovery required |

---

## Common Failures

---

### ASSESSMENT_FAILED: `pending_reboot`

**Cause:** Windows reboot pending flag is set from Windows Update, Group Policy, or a prior operation.

**Fix:**
```bash
aws ssm send-command \
  --instance-ids ${INSTANCE_ID} \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":["Restart-Computer -Force"]}' \
  --comment "Pre-upgrade reboot to clear pending flag"
```
Wait for SSM to come back online (~5 min), then re-run the batch.

---

### ASSESSMENT_FAILED: `disk_space`

**Cause:** C: drive has less than `MinFreeSpaceGB` free (default 20 GB).

**Fix Option A — Clean temp files:**
```bash
aws ssm send-command \
  --instance-ids ${INSTANCE_ID} \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":[
    "Remove-Item C:\\Windows\\Temp\\* -Recurse -Force -ErrorAction SilentlyContinue",
    "Remove-Item C:\\Windows\\SoftwareDistribution\\Download\\* -Recurse -Force -ErrorAction SilentlyContinue",
    "Clear-RecycleBin -Force -ErrorAction SilentlyContinue",
    "$d = Get-PSDrive C; Write-Output \"Free: $([math]::Round($d.Free/1GB,2)) GB\""
  ]}'
```

**Fix Option B — Expand the EBS volume (no downtime):**
```bash
# Get root volume ID
VOLUME_ID=$(aws ec2 describe-instances --instance-ids ${INSTANCE_ID} \
  --query "Reservations[0].Instances[0].BlockDeviceMappings[?DeviceName=='/dev/sda1'].Ebs.VolumeId" \
  --output text)

# Expand to desired size (e.g. 100 GB)
aws ec2 modify-volume --volume-id ${VOLUME_ID} --size 100

# After resize completes, extend the partition on Windows via SSM:
aws ssm send-command \
  --instance-ids ${INSTANCE_ID} \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":["Resize-Partition -DriveLetter C -Size (Get-PartitionSupportedSize -DriveLetter C).SizeMax"]}'
```

---

### ASSESSMENT_FAILED: `upgrade_media`

**Cause:** `C:\UpgradeMedia\setup.exe` not found on the instance.

**Fix:** Stage the media before re-running:
```bash
aws ssm send-command \
  --instance-ids ${INSTANCE_ID} \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":[
    "New-Item -ItemType Directory -Force -Path C:\\UpgradeMedia",
    "Read-S3Object -BucketName ws-upgrade-platform-ACCOUNT_ID -Key media/setup.exe -File C:\\UpgradeMedia\\setup.exe",
    "Write-Output \"Media staged: $((Get-Item C:\\UpgradeMedia\\setup.exe).Length) bytes\""
  ]}'
```

---

### ASSESSMENT_FAILED: `ena_driver`

**Cause:** ENA network driver not found. Required for WS2025 on Nitro instance types.

**Check instance type first:**
```bash
aws ec2 describe-instances --instance-ids ${INSTANCE_ID} \
  --query "Reservations[0].Instances[0].InstanceType" --output text
```

If the instance type is `m3`, `c3`, `r3`, or another pre-Nitro type, it must be changed before upgrading. Contact the application owner.

If the instance type supports ENA but the driver is missing:
```bash
aws ssm send-command \
  --instance-ids ${INSTANCE_ID} \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":[
    "$url = \"https://s3.amazonaws.com/ec2-windows-drivers-downloads/ENA/Latest/AWSEnaNetworkDriver.zip\"",
    "Invoke-WebRequest $url -OutFile C:\\Temp\\ena.zip",
    "Expand-Archive C:\\Temp\\ena.zip -DestinationPath C:\\Temp\\ena -Force",
    "Start-Process -FilePath C:\\Temp\\ena\\install.ps1 -Wait",
    "Restart-Computer -Force"
  ]}'
```

---

### SNAPSHOT_FAILED

**Cause:** EBS snapshot did not reach `completed` state within `SnapshotTimeoutSeconds`.

**Check snapshot status in EC2:**
```bash
aws ec2 describe-snapshots \
  --filters "Name=tag:ws-upgrade-instance,Values=${INSTANCE_ID}" \
            "Name=tag:ws-upgrade-batch,Values=${BATCH_ID}" \
  --query "Snapshots[*].{ID:SnapshotId,State:State,Progress:Progress,Error:StateMessage}" \
  --output table
```

If the snapshot eventually completes: increase `--snapshot-timeout-secs` and re-run.
If the snapshot shows `error` state: check EBS volume health in CloudWatch (VolumeQueueLength, BurstBalance).

---

### WaitForSSMOnlinePostUpgrade timeout

**Cause:** Instance did not bring SSM back online within the configured timeout after upgrade.

**Triage steps:**

1. Check EC2 state:
```bash
aws ec2 describe-instances --instance-ids ${INSTANCE_ID} \
  --query "Reservations[0].Instances[0].State.Name" --output text
```

2. If EC2 is running but SSM is offline — upgrade may still be in progress:
```bash
# Check CloudWatch for CPU/disk activity indicating upgrade still running
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=${INSTANCE_ID} \
  --start-time $(date -u -d '2 hours ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 300 --statistics Average \
  --output table
```
If CPU is active, the upgrade is running. Increase `PostRebootWaitSeconds` for future batches.

3. If EC2 is stopped — the upgrade may have failed to reboot correctly.
   Check EC2 System Log: Console → EC2 → Instance → Monitor and Troubleshoot → Get System Log.
   If the OS failed to boot, proceed to manual rollback below.

---

### ROLLBACK_FAILED — Critical

Both upgrade and rollback failed. The instance may be stopped with no valid root volume attached.

**Immediate steps:**

**Step 1 — Confirm instance state:**
```bash
aws ec2 describe-instances --instance-ids ${INSTANCE_ID} \
  --query "Reservations[0].Instances[0].{State:State.Name,Volumes:BlockDeviceMappings}" \
  --output json
```

**Step 2 — Find the pre-upgrade snapshot from the state file:**
```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
aws s3 cp s3://ws-upgrade-platform-${ACCOUNT_ID}/batches/${BATCH_ID}/state/${INSTANCE_ID}.json - \
  | python3 -c "
import sys, json
s = json.load(sys.stdin)
snaps = s.get('snapshots', {})
for vol_id, snap in snaps.items():
    print(f\"Vol: {vol_id} | Root: {snap.get('is_root')} | Snap: {snap.get('snapshot_id')} | Status: {snap.get('status')}\")
"
```

**Step 3 — Get instance AZ and original volume details:**
```bash
AZ=$(aws ec2 describe-instances --instance-ids ${INSTANCE_ID} \
  --query "Reservations[0].Instances[0].Placement.AvailabilityZone" --output text)
```

**Step 4 — Create restore volume from snapshot:**
```bash
ROOT_SNAPSHOT_ID="snap-0YOURSNAPSHOTID"  # from state file above

NEW_VOL=$(aws ec2 create-volume \
  --availability-zone ${AZ} \
  --snapshot-id ${ROOT_SNAPSHOT_ID} \
  --volume-type gp3 \
  --tag-specifications "ResourceType=volume,Tags=[{Key=Name,Value=manual-recovery-${INSTANCE_ID}}]" \
  --query "VolumeId" --output text)

echo "Restore volume: ${NEW_VOL}"

# Wait for available
aws ec2 wait volume-available --volume-ids ${NEW_VOL}
```

**Step 5 — Ensure instance is stopped:**
```bash
aws ec2 stop-instances --instance-ids ${INSTANCE_ID}
aws ec2 wait instance-stopped --instance-ids ${INSTANCE_ID}
```

**Step 6 — Attach restore volume and start:**
```bash
ROOT_DEVICE="/dev/sda1"  # confirm from state file: root_device field

aws ec2 attach-volume \
  --volume-id ${NEW_VOL} \
  --instance-id ${INSTANCE_ID} \
  --device ${ROOT_DEVICE}

aws ec2 wait volume-in-use --volume-ids ${NEW_VOL}

aws ec2 start-instances --instance-ids ${INSTANCE_ID}
aws ec2 wait instance-running --instance-ids ${INSTANCE_ID}
```

**Step 7 — Confirm SSM comes online:**
```bash
# Poll until Online
for i in $(seq 1 20); do
  STATUS=$(aws ssm describe-instance-information \
    --filters "Key=InstanceIds,Values=${INSTANCE_ID}" \
    --query "InstanceInformationList[0].PingStatus" --output text 2>/dev/null)
  echo "SSM ping: ${STATUS}"
  [ "${STATUS}" = "Online" ] && break
  sleep 30
done
```

**Step 8 — Update S3 state file to reflect manual recovery:**
```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
STATE_KEY="batches/${BATCH_ID}/state/${INSTANCE_ID}.json"

aws s3 cp s3://ws-upgrade-platform-${ACCOUNT_ID}/${STATE_KEY} /tmp/state.json

python3 -c "
import json, sys
from datetime import datetime, timezone
with open('/tmp/state.json') as f:
    s = json.load(f)
s['phase']        = 'MANUALLY_RECOVERED'
s['final_status'] = 'MANUALLY_RECOVERED'
s['last_updated'] = datetime.now(timezone.utc).isoformat()
s['recovery_note'] = 'Manual volume swap performed by engineer after ROLLBACK_FAILED'
with open('/tmp/state.json', 'w') as f:
    json.dump(s, f, indent=2)
"

aws s3 cp /tmp/state.json s3://ws-upgrade-platform-${ACCOUNT_ID}/${STATE_KEY}
echo "State file updated."
```

---

## Escalation Criteria

Escalate to senior engineer or platform owner when:
- Any instance reaches `ROLLBACK_FAILED`
- More than 2 instances in a single batch fail validation (indicates a systemic issue with the upgrade media or environment)
- Snapshot failures affect more than 1 instance per batch
- An instance is left in stopped state with no root volume attached
