# Installation Guide
## Windows Server Upgrade Automation Platform — SSM Native

---

## Prerequisites

### On your Windows machine

| Requirement | Check |
|---|---|
| Python (run as `python`) | `python --version` |
| boto3 installed | `python -c "import boto3; print(boto3.__version__)"` |
| AWS named profile configured | `aws configure list-profiles` |

If boto3 is not installed:
```
pip install boto3
```

### AWS account

| Requirement | How to verify |
|---|---|
| IAM permissions to create roles, policies, S3 buckets, SSM documents | deploy.py will fail fast with a clear error if missing |
| Target EC2 instances have SSM agent installed and Online | Systems Manager → Fleet Manager |
| Target instances running Windows Server 2019 | EC2 → Instance → Platform Details |
| Instance profile with `AmazonSSMManagedInstanceCore` attached to targets | EC2 → Instance → Security → IAM Role |
| VPC endpoints for SSM (ssm, ec2messages, ssmmessages) if using private subnets | VPC → Endpoints |

---

## Project Layout

After unzipping, you should have:

```
ws-upgrade-ssm\
  documents\
    ws-upgrade-per-instance.yaml    <- Full upgrade workflow (one instance)
    ws-upgrade-batch-runner.yaml    <- Batch orchestrator
  iam\
    trust-policy.json               <- SSM service trust
    permission-policy.json          <- EC2 + SSM + S3 permissions
  scripts\
    deploy.py                       <- Run once per account to set up
    run_batch.py                    <- Start a batch
    monitor.py                      <- Watch batch progress
  docs\
    INSTALL.md
    OPERATIONS_RUNBOOK.md
    SUPPORT_RUNBOOK.md
  batch-history\                    <- Created automatically by run_batch.py
```

All three Python scripts live in `scripts\` and are run from there.

---

## Step 1 — Deploy

Open a command prompt or PowerShell window, navigate to `scripts\`, and run:

```
cd ws-upgrade-ssm\scripts

python deploy.py --profile YOUR_PROFILE_NAME
```

Replace `YOUR_PROFILE_NAME` with the profile name from your `~\.aws\credentials` file.

To target a specific region (default is ca-central-1):
```
python deploy.py --profile YOUR_PROFILE_NAME --region ca-central-1
```

**What it creates:**

| Resource | Name |
|---|---|
| S3 Bucket | `ws-upgrade-platform-{your-account-id}` |
| IAM Role | `ws-upgrade-ssm-automation-role` |
| IAM Policy | `ws-upgrade-ssm-automation-policy` |
| SSM Automation Document | `ws-upgrade-per-instance` |
| SSM Automation Document | `ws-upgrade-batch-runner` |

It also writes a `.deploy-config.json` file to the `scripts\` folder.
`run_batch.py` and `monitor.py` read from this file — you never need to
manually enter your account ID, role ARN, or bucket name again.

Safe to re-run — it checks for existing resources and skips or updates as needed.

---

## Step 2 — Stage Upgrade Media

The upgrade document expects Windows Server 2025 setup media at:
```
C:\UpgradeMedia\setup.exe
```
on every target instance.

**Stage it via AWS CLI or the SSM console before running any batch:**

```
aws ssm send-command ^
  --profile YOUR_PROFILE_NAME ^
  --instance-ids i-0abc1234 i-0def5678 ^
  --document-name "AWS-RunPowerShellScript" ^
  --parameters "commands=['New-Item -ItemType Directory -Force -Path C:\UpgradeMedia', 'Copy-S3Object -BucketName ws-upgrade-platform-ACCOUNT_ID -Key media/setup.exe -LocalFile C:\UpgradeMedia\setup.exe']" ^
  --comment "Stage WS2025 upgrade media"
```

The assessment step will check for media presence and stop cleanly if it is not found — no snapshot will be taken, no upgrade will start.

---

## Step 3 — Tag Your Target Instances

Tag-based targeting is recommended. Apply a tag to the instances you want to include in a wave before running:

```
aws ec2 create-tags ^
  --profile YOUR_PROFILE_NAME ^
  --resources i-0abc1234 i-0def5678 ^
  --tags Key=WS-Upgrade-Wave,Value=Wave-01
```

You can use any tag key and value — the `--tag-key` and `--tag-value` parameters in `run_batch.py` control what is queried.

---

## Step 4 — Verify Deployment

```
python deploy.py --profile YOUR_PROFILE_NAME
```

Re-running deploy.py after the first run will show SKIP for everything that already exists and OK for anything that needed updating. That output confirms everything is in place.

---

## Step 5 — Run a Pilot

Before running a full wave, run a single instance to verify the end-to-end flow:

```
python run_batch.py ^
  --profile YOUR_PROFILE_NAME ^
  --batch-id batch-pilot-001 ^
  --instance-ids i-YOUR_PILOT_INSTANCE ^
  --max-concurrency 1
```

Then watch it:
```
python monitor.py ^
  --profile YOUR_PROFILE_NAME ^
  --batch-id batch-pilot-001 ^
  --watch
```

Expected pilot outcome: instance reaches `SUCCESS` or, if upgrade media is not staged, `ASSESSMENT_FAILED` at the `upgrade_media` check. Either result confirms the platform is working.

---

## Multi-Account Deployment

Run `deploy.py` once per AWS account:

```
python deploy.py --profile account-a-profile --region ca-central-1
python deploy.py --profile account-b-profile --region ca-central-1
```

Each account gets its own S3 bucket (named by account ID), IAM role, and SSM documents.
Note: each `deploy.py` run overwrites `.deploy-config.json` with the last account deployed.
When running batches against different accounts, pass `--profile` explicitly each time —
`run_batch.py` will use the profile to authenticate regardless of which config was last written.

---

## Updating SSM Documents

After editing either YAML document, re-run deploy.py:

```
python deploy.py --profile YOUR_PROFILE_NAME
```

It updates both documents to `$LATEST` automatically.

---

## Removing the Platform

```
aws s3 rm s3://ws-upgrade-platform-ACCOUNT_ID --recursive --profile YOUR_PROFILE
aws s3api delete-bucket --bucket ws-upgrade-platform-ACCOUNT_ID --profile YOUR_PROFILE

aws iam detach-role-policy ^
  --role-name ws-upgrade-ssm-automation-role ^
  --policy-arn arn:aws:iam::ACCOUNT_ID:policy/ws-upgrade-ssm-automation-policy ^
  --profile YOUR_PROFILE

aws iam delete-policy ^
  --policy-arn arn:aws:iam::ACCOUNT_ID:policy/ws-upgrade-ssm-automation-policy ^
  --profile YOUR_PROFILE

aws iam delete-role --role-name ws-upgrade-ssm-automation-role --profile YOUR_PROFILE

aws ssm delete-document --name ws-upgrade-per-instance --profile YOUR_PROFILE
aws ssm delete-document --name ws-upgrade-batch-runner --profile YOUR_PROFILE
```
