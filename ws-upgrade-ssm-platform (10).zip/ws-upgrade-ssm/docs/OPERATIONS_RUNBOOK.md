# Operations Runbook
## Windows Server Upgrade Automation Platform — SSM Native

---

## Architecture Overview

```
run-batch.sh
    │
    └── SSM Automation: ws-upgrade-batch-runner
            │  Resolves instances (tag or ID list)
            │  Writes manifest to S3
            │
            └── SSM Automation: ws-upgrade-per-instance  (one per instance)
                    │
                    ├── Step 1: ValidateEC2Running         (assertAwsResourceProperty)
                    ├── Step 2: ValidateSSMOnline           (assertAwsResourceProperty)
                    ├── Step 3: GetInstanceDetails          (executeAwsApi)
                    ├── Step 4: WriteStateLoaded            (executeScript → S3)
                    ├── Step 5: RunAssessment               (runCommand → PowerShell)
                    ├── Step 6: EvaluateAssessment          (executeScript → S3)
                    ├── Step 7: AssessmentPassed?           (branch)
                    ├── Step 8: CreateSnapshots             (executeScript → EC2 API)
                    ├── Step 9: WaitForSnapshots            (executeScript → poll EC2)
                    ├── Step 10: WriteStateSnapshotComplete (executeScript → S3)
                    ├── Step 11: TriggerUpgrade             (runCommand → setup.exe)
                    ├── Step 12: WriteStateUpgradeStarted   (executeScript → S3)
                    ├── Step 13: WaitForRebootWindow        (sleep)
                    ├── Step 14: WaitForSSMOnline           (waitForAwsResourceProperty)
                    ├── Step 15: RunPostUpgradeValidation   (runCommand → PowerShell)
                    ├── Step 16: EvaluateValidation         (executeScript → S3)
                    ├── Step 17: ValidationPassed?          (branch)
                    │
                    ├── SUCCESS PATH
                    │       └── WriteStateFinalSuccess
                    │
                    └── ROLLBACK PATH
                            ├── RollbackStop                (executeAwsApi)
                            ├── WaitForInstanceStopped      (waitForAwsResourceProperty)
                            ├── RollbackDetachVolume        (executeScript → EC2 API)
                            ├── WaitForRestoreVolumeAvailable
                            ├── AttachRestoreVolume         (executeAwsApi)
                            ├── WaitForVolumeAttached
                            ├── RollbackStartInstance       (executeAwsApi)
                            ├── WaitForSSMOnlinePostRollback
                            └── WriteStateRollbackComplete
```

**Audit trail lives in two places:**
- **SSM Automation console** — step-by-step execution history, timestamps, input/output per step
- **S3 state files** — `batches/{batch_id}/state/{instance_id}.json` — structured JSON updated at every phase

---

## Before Running Any Batch

### 1. Tag your target instances

Tag-based targeting is the recommended approach. Apply tags in EC2 before running.

```bash
# Tag a wave of instances
aws ec2 create-tags \
  --resources i-0abc1234 i-0def5678 i-0ghi9012 \
  --tags Key=WS-Upgrade-Wave,Value=Wave-01
```

You can use any tag key/value. The `--tag-key` and `--tag-value` parameters in `run-batch.sh` control what the automation queries for.

### 2. Stage upgrade media on target instances

The upgrade document expects the Windows Server 2025 setup binary at:
```
C:\UpgradeMedia\setup.exe
```

Stage this before running any batch via SSM Run Command:
```bash
# Copy extracted setup.exe from S3 to target instances
aws ssm send-command \
  --instance-ids i-0abc1234 i-0def5678 \
  --document-name "AWS-RunPowerShellScript" \
  --parameters '{"commands":[
    "New-Item -ItemType Directory -Force -Path C:\\UpgradeMedia",
    "Read-S3Object -BucketName ws-upgrade-platform-ACCOUNT_ID -Key media/setup.exe -File C:\\UpgradeMedia\\setup.exe"
  ]}' \
  --comment "Stage WS2025 upgrade media"
```

The assessment step will check for media presence and fail fast if not found — no snapshot will be taken and no upgrade attempted.

### 3. Confirm SSM Fleet Manager shows all instances Online

```bash
aws ssm describe-instance-information \
  --filters "Key=PingStatus,Values=Online" \
  --query "InstanceInformationList[*].{ID:InstanceId,Ping:PingStatus,Version:AgentVersion}" \
  --output table
```

---

## Running a Batch

### Tag-based (recommended)

```bash
./scripts/run-batch.sh \
  --batch-id batch-20250912-001 \
  --tag-key WS-Upgrade-Wave \
  --tag-value Wave-01 \
  --max-concurrency 5
```

### Instance list (for ad-hoc or retry)

```bash
./scripts/run-batch.sh \
  --batch-id batch-20250912-001 \
  --instance-ids "i-0abc1234,i-0def5678,i-0ghi9012" \
  --max-concurrency 3
```

The script will prompt for confirmation before starting. Review the parameters shown, then type `yes`.

---

## Monitoring

### Quick status table

```bash
./scripts/monitor.sh --batch-id batch-20250912-001
```

Shows: server name, instance ID, current phase, final status for every instance in the batch.

### Single instance detail

```bash
./scripts/monitor.sh \
  --batch-id batch-20250912-001 \
  --instance-id i-0abc1234
```

### SSM Automation console

AWS Console → Systems Manager → Automation → Executions

Filter by document name `ws-upgrade-per-instance` to see all child executions.
Click any execution to see the step-by-step visual with inputs/outputs per step — this is your primary audit view.

### Watch S3 state files directly

```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
BUCKET="ws-upgrade-platform-${ACCOUNT_ID}"
BATCH_ID="batch-20250912-001"

# Watch state updates (poll every 60s)
watch -n 60 "aws s3 ls s3://${BUCKET}/batches/${BATCH_ID}/state/"

# Pull a specific instance's state
aws s3 cp s3://${BUCKET}/batches/${BATCH_ID}/state/i-0abc1234.json - \
  | python3 -m json.tool
```

---

## Forcing a Manual Rollback

If you need to roll back an instance outside of an active automation execution:

```bash
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/ws-upgrade-ssm-automation-role"
BUCKET="ws-upgrade-platform-${ACCOUNT_ID}"

aws ssm start-automation-execution \
  --document-name "ws-upgrade-per-instance" \
  --parameters \
    "InstanceId=i-0abc1234,\
BatchId=batch-20250912-001-MANUAL-ROLLBACK,\
S3Bucket=${BUCKET},\
AutomationAssumeRole=${ROLE_ARN}" 
```

**Note:** Running the full document for rollback will re-run assessment and snapshot before rolling back. For a direct rollback-only operation, navigate in the SSM console to the original execution and review which snapshot IDs were created, then perform the volume swap manually using the steps in the Support Runbook.

---

## Tuning Parameters

All parameters can be overridden at run time via `run-batch.sh` flags or in the SSM console when starting manually.

| Parameter | Default | Override Flag | When to Change |
|---|---|---|---|
| `MinFreeSpaceGB` | 20 | `--min-free-space-gb` | If your servers are consistently tight on disk |
| `PostRebootWaitSeconds` | 1200 | `--post-reboot-wait-secs` | Increase for older/slower instance types |
| `UpgradeTimeoutMinutes` | 120 | `--upgrade-timeout-mins` | Increase for very large OS volumes |
| `SnapshotTimeoutSeconds` | 3600 | `--snapshot-timeout-secs` | Increase for large EBS volumes |
| `MaxConcurrency` | 5 | `--max-concurrency` | Increase gradually per wave |

---

## Recommended Wave Sizing

| Wave | Servers | Max Concurrency | Notes |
|---|---|---|---|
| Pilot | 3–5 | 2 | Validate full workflow end to end |
| Wave 1 | 10–15 | 3–5 | First production wave |
| Wave 2 | 20–25 | 5–8 | After Wave 1 exits cleanly |
| Wave 3+ | 25–50 | 10–15 | Production cadence |

---

## Generating a Batch Report

A Python script is provided to generate an Excel report from the S3 state files.

```bash
pip install openpyxl boto3 --quiet

python3 scripts/generate-report.py \
  --batch-id batch-20250912-001 \
  --bucket ws-upgrade-platform-ACCOUNT_ID \
  --output batch-report-20250912-001.xlsx
```

Or pull the JSON summary directly:
```bash
aws s3 cp s3://${BUCKET}/batches/${BATCH_ID}/reports/summary.json - \
  | python3 -m json.tool
```
