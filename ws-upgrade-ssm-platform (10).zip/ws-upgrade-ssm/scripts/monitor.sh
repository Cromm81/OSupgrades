#!/usr/bin/env bash
# =============================================================================
# monitor.sh
# Quick status commands for a running or completed batch.
#
# Usage:
#   ./scripts/monitor.sh --batch-id batch-20250912-001
#   ./scripts/monitor.sh --batch-id batch-20250912-001 --instance-id i-0abc1234
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/.deploy-config"

if [ ! -f "${CONFIG_FILE}" ]; then
    echo "ERROR: .deploy-config not found. Run ./scripts/deploy.sh first."
    exit 1
fi

source "${CONFIG_FILE}"

BATCH_ID=""
INSTANCE_ID=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --batch-id)    BATCH_ID="$2";    shift 2 ;;
        --instance-id) INSTANCE_ID="$2"; shift 2 ;;
        *) echo "Unknown: $1"; exit 1 ;;
    esac
done

if [ -z "${BATCH_ID}" ]; then
    echo "ERROR: --batch-id is required"
    exit 1
fi

echo ""
echo "============================================="
echo "  Batch: ${BATCH_ID}"
echo "============================================="

# ── Manifest ──────────────────────────────────────────────────────────────────
echo ""
echo "--- Manifest ---"
aws s3 cp "s3://${BUCKET}/batches/${BATCH_ID}/manifest.json" - 2>/dev/null \
    | python3 -c "
import sys, json
m = json.load(sys.stdin)
s = m.get('summary', {})
print(f\"  Total resolved : {s.get('total_resolved','?')}\")
print(f\"  Eligible       : {s.get('eligible','?')}\")
print(f\"  Ineligible     : {s.get('ineligible','?')}\")
" || echo "  Manifest not yet written."

# ── Per-instance status summary ───────────────────────────────────────────────
echo ""
echo "--- Instance Status ---"
echo ""
printf "  %-25s %-22s %-28s %s\n" "SERVER NAME" "INSTANCE ID" "PHASE" "FINAL STATUS"
printf "  %-25s %-22s %-28s %s\n" "-----------" "-----------" "-----" "------------"

aws s3 ls "s3://${BUCKET}/batches/${BATCH_ID}/state/" 2>/dev/null \
    | awk '{print $4}' \
    | while read -r key; do
        aws s3 cp "s3://${BUCKET}/batches/${BATCH_ID}/state/${key}" - 2>/dev/null \
            | python3 -c "
import sys, json
s = json.load(sys.stdin)
name   = s.get('server_name', '—')[:24]
iid    = s.get('instance_id', '—')
phase  = s.get('phase', '—')[:27]
status = s.get('final_status') or '—'
print(f'  {name:<25} {iid:<22} {phase:<28} {status}')
" 2>/dev/null
    done

# ── Single instance detail ────────────────────────────────────────────────────
if [ -n "${INSTANCE_ID}" ]; then
    echo ""
    echo "--- Detail: ${INSTANCE_ID} ---"
    aws s3 cp "s3://${BUCKET}/batches/${BATCH_ID}/state/${INSTANCE_ID}.json" - 2>/dev/null \
        | python3 -m json.tool \
        || echo "  State file not found for ${INSTANCE_ID}"
fi

# ── Running SSM Automation child executions ───────────────────────────────────
echo ""
echo "--- Active SSM Executions (InProgress) ---"
aws ssm describe-automation-executions \
    --filters "Key=DocumentName,Values=ws-upgrade-per-instance" \
    --query "AutomationExecutionMetadataList[?AutomationExecutionStatus=='InProgress'].{ID:AutomationExecutionId,Status:AutomationExecutionStatus,Start:ExecutionStartTime}" \
    --output table 2>/dev/null || echo "  None running."

echo ""
