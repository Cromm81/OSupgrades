#!/usr/bin/env bash
# =============================================================================
# deploy.sh
# Creates the S3 bucket, IAM role, and registers both SSM Automation documents.
# Run once per AWS account. Safe to re-run — checks for existing resources.
#
# Prerequisites:
#   - AWS CLI v2 configured with credentials that have IAM, S3, and SSM write access
#   - Run from the root of the ws-upgrade-ssm directory
#
# Usage:
#   chmod +x scripts/deploy.sh
#   ./scripts/deploy.sh
#
# To target a specific AWS profile:
#   AWS_PROFILE=my-profile ./scripts/deploy.sh
# =============================================================================

set -euo pipefail

# ── Resolve account ID and region ────────────────────────────────────────────
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region 2>/dev/null || echo "ca-central-1")
BUCKET="ws-upgrade-platform-${ACCOUNT_ID}"
ROLE_NAME="ws-upgrade-ssm-automation-role"
POLICY_NAME="ws-upgrade-ssm-automation-policy"

echo ""
echo "============================================="
echo "  WS Upgrade Platform — Deployment"
echo "============================================="
echo "  Account : ${ACCOUNT_ID}"
echo "  Region  : ${REGION}"
echo "  Bucket  : ${BUCKET}"
echo "  Role    : ${ROLE_NAME}"
echo "============================================="
echo ""

# ── Step 1: S3 Bucket ────────────────────────────────────────────────────────
echo "[1/5] Creating S3 bucket..."

if aws s3api head-bucket --bucket "${BUCKET}" 2>/dev/null; then
    echo "      Bucket already exists — skipping create"
else
    if [ "${REGION}" = "us-east-1" ]; then
        aws s3api create-bucket \
            --bucket "${BUCKET}" \
            --region "${REGION}"
    else
        aws s3api create-bucket \
            --bucket "${BUCKET}" \
            --region "${REGION}" \
            --create-bucket-configuration LocationConstraint="${REGION}"
    fi
    echo "      Created: s3://${BUCKET}"
fi

# Block public access
aws s3api put-public-access-block \
    --bucket "${BUCKET}" \
    --public-access-block-configuration \
        "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# Enable versioning
aws s3api put-bucket-versioning \
    --bucket "${BUCKET}" \
    --versioning-configuration Status=Enabled

# Enable default encryption
aws s3api put-bucket-encryption \
    --bucket "${BUCKET}" \
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }'

# Lifecycle — move logs to Glacier after 90 days, expire after 365
aws s3api put-bucket-lifecycle-configuration \
    --bucket "${BUCKET}" \
    --lifecycle-configuration '{
        "Rules": [{
            "ID": "archive-and-expire",
            "Status": "Enabled",
            "Filter": {"Prefix": "batches/"},
            "Transitions": [{
                "Days": 90,
                "StorageClass": "GLACIER"
            }],
            "Expiration": {
                "Days": 365
            }
        }]
    }'

echo "      S3 bucket configured."

# ── Step 2: IAM Trust Policy ─────────────────────────────────────────────────
echo "[2/5] Creating IAM role..."

# Substitute account ID into trust policy
TRUST_POLICY=$(sed "s/\${ACCOUNT_ID}/${ACCOUNT_ID}/g" iam/trust-policy.json)

if aws iam get-role --role-name "${ROLE_NAME}" 2>/dev/null; then
    echo "      Role already exists — skipping create"
else
    aws iam create-role \
        --role-name "${ROLE_NAME}" \
        --assume-role-policy-document "${TRUST_POLICY}" \
        --description "SSM Automation execution role for Windows Server upgrade platform" \
        --tags Key=Project,Value=ws-upgrade-platform Key=ManagedBy,Value=deploy-sh
    echo "      Role created: ${ROLE_NAME}"
fi

# ── Step 3: IAM Permission Policy ────────────────────────────────────────────
echo "[3/5] Attaching IAM policy..."

# Substitute account ID into permission policy
PERM_POLICY=$(sed "s/\${ACCOUNT_ID}/${ACCOUNT_ID}/g" iam/permission-policy.json)

# Check if policy exists
POLICY_ARN="arn:aws:iam::${ACCOUNT_ID}:policy/${POLICY_NAME}"

if aws iam get-policy --policy-arn "${POLICY_ARN}" 2>/dev/null; then
    echo "      Policy exists — creating new version..."
    # Delete oldest non-default version if at limit (max 5)
    VERSIONS=$(aws iam list-policy-versions \
        --policy-arn "${POLICY_ARN}" \
        --query "Versions[?IsDefaultVersion==\`false\`].VersionId" \
        --output text)
    for v in $VERSIONS; do
        aws iam delete-policy-version --policy-arn "${POLICY_ARN}" --version-id "$v" 2>/dev/null || true
    done
    aws iam create-policy-version \
        --policy-arn "${POLICY_ARN}" \
        --policy-document "${PERM_POLICY}" \
        --set-as-default
else
    aws iam create-policy \
        --policy-name "${POLICY_NAME}" \
        --policy-document "${PERM_POLICY}" \
        --description "Permissions for ws-upgrade SSM Automation role" \
        --tags Key=Project,Value=ws-upgrade-platform
    echo "      Policy created: ${POLICY_NAME}"
fi

# Attach policy to role
aws iam attach-role-policy \
    --role-name "${ROLE_NAME}" \
    --policy-arn "${POLICY_ARN}"
echo "      Policy attached."

# Wait for IAM propagation
echo "      Waiting 10s for IAM propagation..."
sleep 10

# ── Step 4: Register per-instance document ───────────────────────────────────
echo "[4/5] Registering SSM document: ws-upgrade-per-instance..."

if aws ssm get-document --name "ws-upgrade-per-instance" 2>/dev/null; then
    echo "      Document exists — updating..."
    aws ssm update-document \
        --name "ws-upgrade-per-instance" \
        --content file://documents/ws-upgrade-per-instance.yaml \
        --document-format YAML \
        --document-version "\$LATEST"
    aws ssm update-document-default-version \
        --name "ws-upgrade-per-instance" \
        --document-version "\$LATEST"
else
    aws ssm create-document \
        --name "ws-upgrade-per-instance" \
        --content file://documents/ws-upgrade-per-instance.yaml \
        --document-type Automation \
        --document-format YAML \
        --tags Key=Project,Value=ws-upgrade-platform
    echo "      Created: ws-upgrade-per-instance"
fi

# ── Step 5: Register batch runner document ───────────────────────────────────
echo "[5/5] Registering SSM document: ws-upgrade-batch-runner..."

if aws ssm get-document --name "ws-upgrade-batch-runner" 2>/dev/null; then
    echo "      Document exists — updating..."
    aws ssm update-document \
        --name "ws-upgrade-batch-runner" \
        --content file://documents/ws-upgrade-batch-runner.yaml \
        --document-format YAML \
        --document-version "\$LATEST"
    aws ssm update-document-default-version \
        --name "ws-upgrade-batch-runner" \
        --document-version "\$LATEST"
else
    aws ssm create-document \
        --name "ws-upgrade-batch-runner" \
        --content file://documents/ws-upgrade-batch-runner.yaml \
        --document-type Automation \
        --document-format YAML \
        --tags Key=Project,Value=ws-upgrade-platform
    echo "      Created: ws-upgrade-batch-runner"
fi

# ── Summary ──────────────────────────────────────────────────────────────────
ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}"

echo ""
echo "============================================="
echo "  Deployment complete."
echo "============================================="
echo ""
echo "  S3 Bucket     : s3://${BUCKET}"
echo "  Role ARN      : ${ROLE_ARN}"
echo "  Documents     : ws-upgrade-per-instance"
echo "                  ws-upgrade-batch-runner"
echo ""
echo "  Next step: tag your target instances, then run:"
echo "  ./scripts/run-batch.sh"
echo ""

# Write a config file for run-batch.sh to consume
cat > scripts/.deploy-config << EOF
ACCOUNT_ID=${ACCOUNT_ID}
REGION=${REGION}
BUCKET=${BUCKET}
ROLE_ARN=${ROLE_ARN}
EOF

echo "  Config written to scripts/.deploy-config"
echo ""
