#!/usr/bin/env bash
# =============================================================================
# run-batch.sh
# Starts a Windows Server upgrade batch via SSM Automation.
#
# Two modes:
#   --tag-key / --tag-value   : target all EC2 instances with matching tag
#   --instance-ids            : target specific comma-separated instance IDs
#
# Usage examples:
#
#   Tag-based (recommended for waves):
#     ./scripts/run-batch.sh \
#       --batch-id batch-20250912-001 \
#       --tag-key WS-Upgrade-Wave \
#       --tag-value Wave-01 \
#       --max-concurrency 5
#
#   Instance list:
#     ./scripts/run-batch.sh \
#       --batch-id batch-20250912-001 \
#       --instance-ids "i-0abc1234,i-0def5678" \
#       --max-concurrency 3
#
# Optional overrides (all have defaults from deploy):
#   --min-free-space-gb    (default: 20)
#   --upgrade-timeout-mins (default: 120)
#   --post-reboot-wait-secs (default: 1200)
#   --snapshot-timeout-secs (default: 3600)
# =============================================================================

set -euo pipefail

# ── Load deploy config ────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/.deploy-config"

if [ ! -f "${CONFIG_FILE}" ]; then
    echo "ERROR: .deploy-config not found. Run ./scripts/deploy.sh first."
    exit 1
fi

source "${CONFIG_FILE}"

# ── Defaults ─────────────────────────────────────────────────────────────────
BATCH_ID=""
TARGET_MODE=""
TAG_KEY="WS-Upgrade-Wave"
TAG_VALUE=""
INSTANCE_IDS=""
MAX_CONCURRENCY="5"
MIN_FREE_SPACE_GB="20"
UPGRADE_TIMEOUT_MINS="120"
POST_REBOOT_WAIT_SECS="1200"
SNAPSHOT_TIMEOUT_SECS="3600"

# ── Parse arguments ───────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --batch-id)             BATCH_ID="$2";               shift 2 ;;
        --tag-key)              TAG_KEY="$2"; TARGET_MODE="ByTag"; shift 2 ;;
        --tag-value)            TAG_VALUE="$2"; TARGET_MODE="ByTag"; shift 2 ;;
        --instance-ids)         INSTANCE_IDS="$2"; TARGET_MODE="ByInstanceList"; shift 2 ;;
        --max-concurrency)      MAX_CONCURRENCY="$2";        shift 2 ;;
        --min-free-space-gb)    MIN_FREE_SPACE_GB="$2";      shift 2 ;;
        --upgrade-timeout-mins) UPGRADE_TIMEOUT_MINS="$2";   shift 2 ;;
        --post-reboot-wait-secs) POST_REBOOT_WAIT_SECS="$2"; shift 2 ;;
        --snapshot-timeout-secs) SNAPSHOT_TIMEOUT_SECS="$2"; shift 2 ;;
        *)
            echo "Unknown argument: $1"
            echo "Run with --help for usage."
            exit 1
            ;;
    esac
done

# ── Validate required args ────────────────────────────────────────────────────
if [ -z "${BATCH_ID}" ]; then
    echo "ERROR: --batch-id is required. Example: batch-20250912-001"
    exit 1
fi

if [ -z "${TARGET_MODE}" ]; then
    echo "ERROR: Specify either --tag-key + --tag-value, or --instance-ids"
    exit 1
fi

if [ "${TARGET_MODE}" = "ByTag" ] && [ -z "${TAG_VALUE}" ]; then
    echo "ERROR: --tag-value is required when using --tag-key"
    exit 1
fi

if [ "${TARGET_MODE}" = "ByInstanceList" ] && [ -z "${INSTANCE_IDS}" ]; then
    echo "ERROR: --instance-ids is required when not using tag mode"
    exit 1
fi

# Validate batch ID format
if ! echo "${BATCH_ID}" | grep -qE '^batch-[a-zA-Z0-9\-]+$'; then
    echo "ERROR: Batch ID must match pattern: batch-{alphanumeric-hyphens}"
    echo "       Example: batch-20250912-001"
    exit 1
fi

# ── Confirm before starting ───────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  WS Upgrade — Starting Batch"
echo "============================================="
echo "  Batch ID        : ${BATCH_ID}"
echo "  Target Mode     : ${TARGET_MODE}"
if [ "${TARGET_MODE}" = "ByTag" ]; then
    echo "  Tag             : ${TAG_KEY}=${TAG_VALUE}"
else
    echo "  Instance IDs    : ${INSTANCE_IDS}"
fi
echo "  Max Concurrency : ${MAX_CONCURRENCY}"
echo "  Min Free Space  : ${MIN_FREE_SPACE_GB} GB"
echo "  Upgrade Timeout : ${UPGRADE_TIMEOUT_MINS} min"
echo "  Post-Reboot Wait: ${POST_REBOOT_WAIT_SECS} sec"
echo "  S3 Bucket       : s3://${BUCKET}"
echo "  IAM Role        : ${ROLE_ARN}"
echo "============================================="
echo ""
read -rp "Proceed? (yes/no): " CONFIRM

if [ "${CONFIRM}" != "yes" ]; then
    echo "Aborted."
    exit 0
fi

# ── Start SSM Automation ──────────────────────────────────────────────────────
echo ""
echo "Starting SSM Automation batch runner..."

EXECUTION_ID=$(aws ssm start-automation-execution \
    --document-name "ws-upgrade-batch-runner" \
    --parameters \
        "BatchId=${BATCH_ID},\
S3Bucket=${BUCKET},\
AutomationAssumeRole=${ROLE_ARN},\
TargetMode=${TARGET_MODE},\
TagKey=${TAG_KEY},\
TagValue=${TAG_VALUE},\
InstanceIds=${INSTANCE_IDS},\
MaxConcurrency=${MAX_CONCURRENCY},\
MinFreeSpaceGB=${MIN_FREE_SPACE_GB},\
UpgradeTimeoutMinutes=${UPGRADE_TIMEOUT_MINS},\
PostRebootWaitSeconds=${POST_REBOOT_WAIT_SECS},\
SnapshotTimeoutSeconds=${SNAPSHOT_TIMEOUT_SECS}" \
    --query "AutomationExecutionId" \
    --output text)

echo ""
echo "============================================="
echo "  Batch started."
echo "============================================="
echo ""
echo "  Execution ID  : ${EXECUTION_ID}"
echo "  Batch ID      : ${BATCH_ID}"
echo ""
echo "  Monitor in console:"
echo "  https://console.aws.amazon.com/systems-manager/automation/executions/${EXECUTION_ID}"
echo ""
echo "  Monitor via CLI:"
echo "  aws ssm describe-automation-executions \\"
echo "    --filters Key=ExecutionId,Values=${EXECUTION_ID}"
echo ""
echo "  Watch per-instance states in S3:"
echo "  aws s3 ls s3://${BUCKET}/batches/${BATCH_ID}/state/"
echo ""
echo "  Pull batch manifest:"
echo "  aws s3 cp s3://${BUCKET}/batches/${BATCH_ID}/manifest.json - | python3 -m json.tool"
echo ""

# Write execution record locally for easy reference
mkdir -p "${SCRIPT_DIR}/../batch-history"
cat > "${SCRIPT_DIR}/../batch-history/${BATCH_ID}.json" << EOF
{
  "batch_id":     "${BATCH_ID}",
  "execution_id": "${EXECUTION_ID}",
  "target_mode":  "${TARGET_MODE}",
  "tag_key":      "${TAG_KEY}",
  "tag_value":    "${TAG_VALUE}",
  "instance_ids": "${INSTANCE_IDS}",
  "started_at":   "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "account_id":   "${ACCOUNT_ID}",
  "region":       "${REGION}",
  "s3_bucket":    "${BUCKET}"
}
EOF

echo "  Local record:  batch-history/${BATCH_ID}.json"
echo ""
