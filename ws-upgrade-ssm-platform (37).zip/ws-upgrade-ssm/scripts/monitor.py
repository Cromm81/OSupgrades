"""
monitor.py
----------
Monitor a ws-upgrade batch (setup or cleanup).

Usage:
    python monitor.py --batch-id BATCH_ID [--profile PROFILE]
    python monitor.py --batch-id BATCH_ID --watch
    python monitor.py --batch-id BATCH_ID --failures
    python monitor.py --batch-id BATCH_ID --instance-id i-xxxx --ssm-detail
"""
import argparse
import boto3
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR  = Path(__file__).parent.resolve()
CONFIG_FILE = SCRIPT_DIR / ".deploy-config.json"

TERMINAL = {
    "SUCCESS", "ASSESSMENT_FAILED", "SNAPSHOT_FAILED",
    "SETUP_FAILED", "VALIDATION_FAILED", "CLEANUP_FAILED",
    "PREVALIDATION_FAILED"
}

USE_COLOUR = os.environ.get("MONITOR_NO_COLOUR", "0") != "1"

def c(text, code): return f"\033[{code}m{text}\033[0m" if USE_COLOUR else str(text)
GREEN  = lambda t: c(t, "32")
YELLOW = lambda t: c(t, "33")
RED    = lambda t: c(t, "31")
CYAN   = lambda t: c(t, "36")
DIM    = lambda t: c(t, "2")
BOLD   = lambda t: c(t, "1")


def load_config():
    if not CONFIG_FILE.exists():
        print("\n  ERROR: .deploy-config.json not found. Run deploy.py first.\n")
        sys.exit(1)
    return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))


def get_session(profile, region):
    try:
        session = boto3.Session(profile_name=profile, region_name=region) if profile \
                  else boto3.Session(region_name=region)
        session.client("sts").get_caller_identity()
        return session
    except Exception as e:
        print(f"\n  ERROR: Auth failed: {e}\n")
        sys.exit(1)


def read_manifest(s3, bucket, batch_id):
    try:
        obj = s3.get_object(Bucket=bucket, Key=f"batches/{batch_id}/manifest.json")
        return json.loads(obj["Body"].read())
    except Exception:
        return None


def list_state_files(s3, bucket, batch_id):
    keys = []
    pager = s3.get_paginator("list_objects_v2")
    for page in pager.paginate(Bucket=bucket, Prefix=f"batches/{batch_id}/state/"):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".json"):
                keys.append(obj["Key"])
    return keys


def read_state(s3, bucket, key):
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(obj["Body"].read())
    except Exception:
        return None


def find_execution(ssm, batch_id, instance_id, doc_prefix):
    try:
        resp = ssm.describe_automation_executions(
            Filters=[
                {"Key": "DocumentNamePrefix", "Values": [doc_prefix]},
                {"Key": "ExecutionStatus",    "Values": [
                    "InProgress", "Success", "Failed", "TimedOut", "Cancelled", "Waiting"
                ]}
            ],
            MaxResults=50
        )
        for ex in resp.get("AutomationExecutionMetadataList", []):
            p = ex.get("Parameters", {})
            if (p.get("InstanceId", [None])[0] == instance_id and
                    p.get("BatchId", [None])[0] == batch_id):
                return ex["AutomationExecutionId"]
    except Exception:
        pass
    return None


def get_execution(ssm, exec_id):
    try:
        return ssm.get_automation_execution(AutomationExecutionId=exec_id)["AutomationExecution"]
    except Exception:
        return None


def elapsed(ts):
    if not ts:
        return "—"
    try:
        t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        s = int((datetime.now(timezone.utc) - t).total_seconds())
        h, r = divmod(abs(s), 3600)
        m, sec = divmod(r, 60)
        return f"{h}h{m}m{sec}s" if h else f"{m}m{sec}s"
    except Exception:
        return "—"


def trunc(s, n):
    s = str(s or "")
    return s[:n-3] + "..." if len(s) > n else s


def fmt_status(s):
    if not s:          return DIM("IN PROGRESS")
    if s == "SUCCESS": return GREEN(s)
    if "FAILED" in s:  return RED(s)
    return CYAN(s)


def fmt_phase(p):
    if not p:                    return DIM("—")
    if p == "COMPLETE":          return GREEN(p)
    if p == "READY_FOR_UPGRADE": return YELLOW(p)
    if "FAILED" in p:            return RED(p)
    return CYAN(p)


def print_manifest(manifest):
    if not manifest:
        print(DIM("  Manifest not yet written."))
        return
    s = manifest.get("summary", {})
    print(f"  Mode      : {manifest.get('mode','—')}  Target: {manifest.get('target_mode','—')}")
    print(f"  Resolved  : {s.get('total_resolved','—')}  "
          f"Eligible: {GREEN(s.get('eligible','—'))}  "
          f"Ineligible: {YELLOW(s.get('ineligible',0))}")
    for item in manifest.get("ineligible_instances", []):
        print(f"              {YELLOW(item['instance_id'])} — {item.get('issues','')}")


def print_table(states):
    if not states:
        print(DIM("  No state files found yet."))
        return {}

    W = {"name": 26, "iid": 21, "phase": 26, "status": 28, "elapsed": 10}
    print(f"  {BOLD('SERVER'):<34} {BOLD('INSTANCE ID'):<21} "
          f"{BOLD('PHASE'):<34} {BOLD('STATUS'):<36} {BOLD('ELAPSED')}")
    print("  " + "-" * 110)

    counts = {"SUCCESS": 0, "FAILED": 0, "IN_PROGRESS": 0, "READY": 0}
    for state in sorted(states, key=lambda x: x.get("server_name", "")):
        name   = trunc(state.get("server_name") or "—", W["name"])
        iid    = state.get("instance_id", "—")
        phase  = state.get("phase", "—")
        status = state.get("final_status")
        ts     = state.get("setup_complete_at") or state.get("last_updated")

        if status == "SUCCESS":                      counts["SUCCESS"] += 1
        elif status and "FAILED" in status:          counts["FAILED"]  += 1
        elif phase == "READY_FOR_UPGRADE":           counts["READY"]   += 1
        else:                                        counts["IN_PROGRESS"] += 1

        print(f"  {name:<26} {iid:<21} "
              f"{fmt_phase(phase):<{W['phase']+16}} "
              f"{fmt_status(status):<{W['status']+16}} "
              f"{elapsed(ts)}")

    print()
    total = sum(counts.values())
    print(f"  {total} instances — "
          f"{GREEN(counts['SUCCESS'])} success  "
          f"{YELLOW(counts['READY'])} ready for upgrade  "
          f"{RED(counts['FAILED'])} failed  "
          f"{DIM(counts['IN_PROGRESS'])} in progress")
    return counts


def print_failures(states, ssm, batch_id):
    failed = [s for s in states if s.get("final_status") and "FAILED" in s["final_status"]]
    if not failed:
        print(f"\n  {GREEN('No failures.')}")
        return
    print(f"\n{BOLD('  FAILURES')}")
    print("  " + "-" * 70)
    for state in failed:
        iid  = state.get("instance_id", "—")
        name = state.get("server_name", iid)
        print(f"\n  {RED('FAIL')} {BOLD(name)} ({iid})")
        print(f"  Phase  : {state.get('phase','—')}")
        print(f"  Status : {state.get('final_status','—')}")
        issues = state.get("assessment_issues") or state.get("validation_issues")
        if issues:
            print(f"  Issues : {RED(str(issues))}")

        for doc in ["ws-upgrade-setup", "ws-upgrade-cleanup"]:
            exec_id = find_execution(ssm, batch_id, iid, doc)
            if exec_id:
                print(f"  Exec   : {exec_id} ({doc})")
                execution = get_execution(ssm, exec_id)
                if execution:
                    for step in execution.get("StepExecutions", []):
                        if step.get("StepStatus") in ("Failed", "TimedOut"):
                            sname = step.get("StepName", "—")
                            smsg  = step.get("FailureMessage", "")
                            print(f"\n  {RED('Failed step')}: {BOLD(sname)}")
                            for line in smsg.split("\n")[:15]:
                                line = line.strip()
                                if line:
                                    print(f"    {line}")
                            outputs = step.get("Outputs", {})
                            cmd_out = None
                            if "Output" in outputs:
                                cmd_out = "\n".join(outputs["Output"])
                            if cmd_out:
                                print(f"  {BOLD('Output')}:")
                                for line in cmd_out.split("\n")[:20]:
                                    line = line.strip()
                                    if line:
                                        print(f"    {line}")


def print_ssm_steps(ssm, batch_id, instance_id):
    print(f"\n{BOLD('  SSM Step Detail')} — {instance_id}")
    for doc in ["ws-upgrade-setup", "ws-upgrade-cleanup"]:
        exec_id = find_execution(ssm, batch_id, instance_id, doc)
        if not exec_id:
            continue
        execution = get_execution(ssm, exec_id)
        if not execution:
            continue
        print(f"\n  {BOLD(doc)} — {exec_id}  [{execution.get('AutomationExecutionStatus','—')}]")
        for step in execution.get("StepExecutions", []):
            sname   = step.get("StepName", "—")
            sstatus = step.get("StepStatus", "—")
            smsg    = step.get("FailureMessage", "")
            icon = GREEN("OK") if sstatus == "Success" else \
                   RED(sstatus) if sstatus in ("Failed", "TimedOut") else \
                   CYAN("RUNNING") if sstatus == "InProgress" else DIM(sstatus)
            print(f"    {icon:<20} {sname}")
            if smsg:
                for line in smsg.split("\n")[:8]:
                    line = line.strip()
                    if line:
                        print(f"               {RED(line)}")


def print_instance_detail(state, ssm, batch_id, ssm_detail=False):
    if not state:
        print(RED("  State file not found."))
        return
    iid = state.get("instance_id", "—")
    print()
    fields = [
        ("Instance ID",      state.get("instance_id")),
        ("Server Name",      state.get("server_name")),
        ("Phase",            state.get("phase")),
        ("Final Status",     state.get("final_status") or "IN PROGRESS"),
        ("AZ",               state.get("az")),
        ("OS Version",       state.get("os_version")),
        ("OS Build",         state.get("os_build")),
        ("Free Space GB",    state.get("free_space_gb")),
        ("Media Volume",     state.get("media_volume_id")),
        ("Drive Letter",     state.get("drive_letter")),
        ("Upgrade Command",  state.get("upgrade_command")),
        ("Setup Complete",   state.get("setup_complete_at")),
        ("Validated At",     state.get("validated_at")),
        ("Last Updated",     state.get("last_updated")),
    ]
    for label, value in fields:
        if value:
            print(f"  {label:<22}: {value}")

    issues = state.get("assessment_issues") or state.get("validation_issues")
    if issues:
        print(f"\n  {RED('Issues')}: {issues}")

    if ssm_detail:
        print_ssm_steps(ssm, batch_id, iid)
    else:
        for doc in ["ws-upgrade-setup", "ws-upgrade-cleanup"]:
            exec_id = find_execution(ssm, batch_id, iid, doc)
            if exec_id:
                print(f"  {doc:<30}: {exec_id}")
        print(f"\n  Tip: add --ssm-detail for full step output")


def run_once(s3, ssm, bucket, batch_id, args):
    print()
    print("=" * 70)
    print(f"  Batch: {BOLD(batch_id)}   {DIM(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")
    print("=" * 70)

    manifest = read_manifest(s3, bucket, batch_id)
    print()
    print(BOLD("  Manifest"))
    print_manifest(manifest)

    keys   = list_state_files(s3, bucket, batch_id)
    states = [read_state(s3, bucket, k) for k in keys]
    states = [s for s in states if s]

    print()
    print(BOLD("  Instance Status"))
    print()
    counts = print_table(states)

    if args.failures:
        print_failures(states, ssm, batch_id)

    if args.instance_id:
        print()
        print(BOLD(f"  Detail — {args.instance_id}"))
        state = next((s for s in states if s.get("instance_id") == args.instance_id), None)
        if not state:
            state = read_state(s3, bucket,
                               f"batches/{batch_id}/state/{args.instance_id}.json")
        print_instance_detail(state, ssm, batch_id, getattr(args, "ssm_detail", False))

    return states


def main():
    parser = argparse.ArgumentParser(description="Monitor a ws-upgrade batch")
    parser.add_argument("--profile",        default=None)
    parser.add_argument("--batch-id",       required=True)
    parser.add_argument("--instance-id",    default=None)
    parser.add_argument("--watch",          action="store_true")
    parser.add_argument("--watch-interval", type=int, default=60)
    parser.add_argument("--failures",       action="store_true")
    parser.add_argument("--ssm-detail",     action="store_true")
    parser.add_argument("--snapshots",       action="store_true",
                        help="List all snapshots for this batch with current status and delete commands")
    parser.add_argument("--region",         default=None)
    args = parser.parse_args()

    config  = load_config()
    region  = args.region or config["region"]
    session = get_session(args.profile, region)
    s3      = session.client("s3",  region_name=region)
    ssm     = session.client("ssm", region_name=region)
    ec2     = session.client("ec2", region_name=region)
    bucket  = config["bucket"]

    if args.snapshots:
        list_all_snapshots(s3, ec2, bucket, args.batch_id)
        print()
        return

    if args.watch:
        i = 1
        while True:
            os.system("cls" if os.name == "nt" else "clear")
            print(DIM(f"  Refresh #{i} — Ctrl+C to stop"))
            states = run_once(s3, ssm, bucket, args.batch_id, args)
            all_done = len(states) > 0 and all(
                s.get("final_status") in TERMINAL or s.get("phase") == "READY_FOR_UPGRADE"
                for s in states
            )
            if all_done:
                print()
                print(GREEN("  All instances complete or ready for upgrade."))
                break
            print()
            print(DIM(f"  Next refresh in {args.watch_interval}s — Ctrl+C to stop"))
            time.sleep(args.watch_interval)
            i += 1
    else:
        run_once(s3, ssm, bucket, args.batch_id, args)
        print()


if __name__ == "__main__":
    main()


def list_all_snapshots(s3, ec2, bucket, batch_id=None):
    """List all snapshots across all batches or a specific batch."""
    print()
    print(BOLD("  Snapshots"))
    print()

    prefix = f"batches/{batch_id}/state/" if batch_id else "batches/"
    keys   = []
    pager  = s3.get_paginator("list_objects_v2")
    for page in pager.paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".json") and "/state/" in obj["Key"]:
                keys.append(obj["Key"])

    all_snap_ids = []
    for key in keys:
        state = read_state(s3, bucket, key)
        if not state:
            continue
        iid      = state.get("instance_id", "—")
        name     = state.get("server_name", iid)
        snap_ids = state.get("snapshot_ids", [])
        snaps    = state.get("snapshots", {})
        if not snap_ids and snaps:
            snap_ids = [v.get("snapshot_id") for v in snaps.values() if v.get("snapshot_id")]

        if snap_ids:
            print(f"  {name} ({iid})")
            for sid in snap_ids:
                all_snap_ids.append(sid)
                # Check current status
                try:
                    resp  = ec2.describe_snapshots(SnapshotIds=[sid])
                    snap  = resp["Snapshots"][0]
                    state_s = snap["State"]
                    size  = snap["VolumeSize"]
                    desc  = snap.get("Description", "")[:50]
                    color = GREEN if state_s == "completed" else YELLOW
                    print(f"    {color(state_s):<20} {sid}  {size}GB  {desc}")
                except Exception:
                    print(f"    {RED('NOT FOUND'):<20} {sid}  (already deleted or wrong account)")

    if not all_snap_ids:
        print(DIM("  No snapshots found in state files."))
        return

    print()
    print(f"  Total: {len(all_snap_ids)} snapshots")
    print()
    print(f"  To delete all:")
    for sid in all_snap_ids:
        print(f"    aws ec2 delete-snapshot --snapshot-id {sid} --profile YOUR_PROFILE")
